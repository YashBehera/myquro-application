import {pgTable, text, date} from "drizzle-orm/pg-core";
import { restaurants } from "./restaurants";
import { authUsers } from "./auth-users";

export const offers = pgTable("offers", {
    id: text("id").notNull().unique().primaryKey(),
    description: text("description").notNull(),
    discountPercentage: text("discount_percentage").notNull(),
    restaurantId: text("restaurant_id").references(() => restaurants.id, { onDelete: "cascade" }),
    createdAt: date("created_at").notNull().defaultNow(),
    createdBy: text("created_by").references(() => authUsers.id, { onDelete: "cascade" }),
});