import { pgTable, text, date } from "drizzle-orm/pg-core";
import { restaurants } from "./restaurants";

export const notifications = pgTable("notifications", {
    id: text("id").notNull().unique().primaryKey(),
    message: text("message").notNull(),
    type: text("type").notNull(),
    restaurantId: text("restaurant_id").references(() => restaurants.id, { onDelete: "cascade" }),
    createdAt: date("created_at").notNull().defaultNow(),});