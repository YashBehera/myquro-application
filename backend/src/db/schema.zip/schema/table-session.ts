import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import { restaurants } from "./restaurants";
import { authUsers } from "./auth-users";
import { tables } from "./tables";
import { tableQR } from "./table-qr";

export const tableSession = pgTable("table_session", {
  id: text("id").notNull().primaryKey(),

  tableId: text("table_id").references(() => tables.id, { onDelete: "cascade" }),

  restaurantId: text("restaurant_id")
    .notNull()
    .references(() => restaurants.id, { onDelete: "cascade" }),

  qrToken: text("qr_token").references(() => tableQR.qrToken, { onDelete: "cascade" }),

  // ---------------------------------------
  // SESSION STATUS
  // ---------------------------------------
  status: text("status")
    .notNull()
    .default("active")
    .$type<"active" | "closed" | "cancelled" | "payment_pending">(),

  paymentStatus: text("payment_status")
    .notNull()
    .default("unpaid")
    .$type<"unpaid" | "paid" | "partial" | "payment_pending">(),

  createdByUserId: text("created_by_user_id").references(() => authUsers.id),

  startedAt: timestamp("started_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),

  // ---------------------------------------
  // DISCOUNT (ALL VALUES IN PAISE LOGIC)
  // ---------------------------------------
  discountPercentage: integer("discount_percentage").default(0), // 0–100%
  discountReason: text("discount_reason"),
  discountApprovedByUserId: text("discount_approved_by_user_id").references(
    () => authUsers.id
  ),
  discountApprovedAt: timestamp("discount_approved_at"),

  // ---------------------------------------
  // FINAL BILL SNAPSHOT (PAISE)
  // This is created ONLY when bill is frozen
  // ---------------------------------------

  subtotal: integer("subtotal").notNull().default(0), // paise
  discountAmount: integer("discount_amount").notNull().default(0), // paise
  taxableBase: integer("taxable_base").notNull().default(0), // paise
  gstRate: integer("gst_rate").notNull().default(0), // integer percent
  gstAmount: integer("gst_amount").notNull().default(0), // paise
  grandTotal: integer("grand_total").notNull().default(0), // paise

  // Frozen snapshot fields

  frozenSubtotal: integer("frozen_subtotal"), // paise
  frozenDiscountAmount: integer("frozen_discount_amount"), // paise
  frozenTaxableAmount: integer("frozen_taxable_amount"), // paise
  frozenGstRate: integer("frozen_gst_rate"), // integer percent
  frozenGstAmount: integer("frozen_gst_amount"), // paise

  finalBillAmount: integer("final_bill_amount"), // paise (grand total)
  billedAt: timestamp("billed_at"), // timestamp of freeze

  invoiceNumber: text("invoice_number"),
});
