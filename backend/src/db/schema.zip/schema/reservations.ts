import {pgTable, text, timestamp, integer} from "drizzle-orm/pg-core";
import {restaurants} from "./restaurants";
import {authUsers} from "./auth-users";

export const reservations = pgTable("reservations", {
    id: text("id").notNull().primaryKey(),

    restaurantId: text("restaurant_id")
        .notNull()
        .references(() => restaurants.id, {onDelete: "cascade"}),

    reservationTime: timestamp("reservation_time").notNull(),
    numberOfGuests: integer("number_of_guests").notNull(),
    reservedBy: text("reserved_by")
        .notNull()
        .references(() => authUsers.id, {onDelete: "cascade"}),
    reservedAt: timestamp("reserved_at").defaultNow().notNull(),
    specialRequests: text("special_requests"),
    status: text("status")
        .notNull()
        .default("pending")
        .$type<"pending" | "confirmed" | "cancelled" | "rejected" | "completed">(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
});