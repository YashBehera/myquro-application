import { pgTable, text, timestamp, integer, real } from "drizzle-orm/pg-core";

import { orders } from "./orders";
import { menuItems } from "./menu-items";
import { menuItemVariants } from "./menu-item-variants";
import { tableSession } from "./table-session";
import { restaurants } from "./restaurants";

export const orderItems = pgTable("order_items", {
  id: text("id").notNull().primaryKey(),
  orderId: text("order_id")
    .notNull()
    .references(() => orders.id, { onDelete: "cascade" }),
  menuItemId: text("menu_item_id")
    .notNull()
    .references(() => menuItems.id, { onDelete: "cascade" }),
  menuItemVariantId: text("menu_item_variant_id")
    .notNull()
    .references(() => menuItemVariants.id, { onDelete: "cascade" }),

  tableSessionId: text("table_session_id")
    .references(() => tableSession.id, { onDelete: "cascade" }),
  restaurantId: text("restaurant_id")
    .notNull()
    .references(() => restaurants.id, { onDelete: "cascade" }),
  quantity: integer("quantity").notNull().default(1),
  unitPrice: integer("unit_price").notNull(),
  totalPrice: integer("total_price").notNull(),
  notes: text("notes"),
  status: text("status")
    .notNull()
    .default("placed")
    .$type<"placed" | "preparing" | "served" | "cancelled">(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
