import { Router } from "express";
import { requireAuth } from "../auth/requireAuth";
import { db } from "../db/db";
import { orders } from "../db/schema/orders";
import { orderItems } from "../db/schema/order-items";
import { menuItems } from "../db/schema/menu-items";
import { reservations } from "../db/schema/reservations";

const router = Router();

// GET /:restaurantId/analytics/income/all-time
router.get(
  "/:restaurantId/analytics/income/all-time",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      // Get all-time successful payments
      const result = await db
        .select({
          totalIncome: sql<number>`COALESCE(SUM(${payments.amount}), 0)`,
          totalTransactions: sql<number>`COUNT(*)`,
        })
        .from(payments)
        .where(
          and(
            eq(payments.restaurantId, restaurantId),
            eq(payments.status, "success"),
            eq(payments.isRefund, false)
          )
        );

      return res.status(200).json({
        totalIncome: result[0]?.totalIncome || 0,
        totalTransactions: result[0]?.totalTransactions || 0,
        currency: "INR",
        unit: "paise",
      });
    } catch (error) {
      console.error("Error fetching all-time income:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /:restaurantId/analytics/income/daily
router.get(
  "/:restaurantId/analytics/income/daily",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { date } = req.query; // Optional date parameter (YYYY-MM-DD)

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      // Parse date or use today
      let targetDate: Date;
      if (date && typeof date === "string") {
        targetDate = new Date(date);
        if (isNaN(targetDate.getTime())) {
          return res.status(400).json({ message: "Invalid date format" });
        }
      } else {
        targetDate = new Date();
      }

      // Set start and end of the day
      const startOfDay = new Date(targetDate);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(targetDate);
      endOfDay.setHours(23, 59, 59, 999);

      // Get daily payments
      const result = await db
        .select({
          totalIncome: sql<number>`COALESCE(SUM(${payments.amount}), 0)`,
          totalTransactions: sql<number>`COUNT(*)`,
        })
        .from(payments)
        .where(
          and(
            eq(payments.restaurantId, restaurantId),
            eq(payments.status, "success"),
            eq(payments.isRefund, false),
            gte(payments.createdAt, startOfDay),
            lte(payments.createdAt, endOfDay)
          )
        );

      return res.status(200).json({
        date: targetDate.toISOString().split("T")[0],
        totalIncome: result[0]?.totalIncome || 0,
        totalTransactions: result[0]?.totalTransactions || 0,
        currency: "INR",
        unit: "paise",
      });
    } catch (error) {
      console.error("Error fetching daily income:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /:restaurantId/analytics/income/hourly
router.get(
  "/:restaurantId/analytics/income/hourly",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { date } = req.query; // Optional date parameter (YYYY-MM-DD)

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      // Parse date or use today
      let targetDate: Date;
      if (date && typeof date === "string") {
        targetDate = new Date(date);
        if (isNaN(targetDate.getTime())) {
          return res.status(400).json({ message: "Invalid date format" });
        }
      } else {
        targetDate = new Date();
      }

      // Set start and end of the day
      const startOfDay = new Date(targetDate);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(targetDate);
      endOfDay.setHours(23, 59, 59, 999);

      // Get hourly breakdown
      const result = await db
        .select({
          hour: sql<number>`EXTRACT(HOUR FROM ${payments.createdAt})`,
          totalIncome: sql<number>`COALESCE(SUM(${payments.amount}), 0)`,
          totalTransactions: sql<number>`COUNT(*)`,
        })
        .from(payments)
        .where(
          and(
            eq(payments.restaurantId, restaurantId),
            eq(payments.status, "success"),
            eq(payments.isRefund, false),
            gte(payments.createdAt, startOfDay),
            lte(payments.createdAt, endOfDay)
          )
        )
        .groupBy(sql`EXTRACT(HOUR FROM ${payments.createdAt})`)
        .orderBy(sql`EXTRACT(HOUR FROM ${payments.createdAt})`);

      // Format hourly data
      const hourlyData = result.map((row) => ({
        hour: row.hour,
        hourRange: `${String(row.hour).padStart(2, "0")}:00 - ${String(
          row.hour
        ).padStart(2, "0")}:59`,
        totalIncome: row.totalIncome,
        totalTransactions: row.totalTransactions,
      }));

      // Calculate total for the day
      const totalDayIncome = hourlyData.reduce(
        (sum, item) => sum + item.totalIncome,
        0
      );
      const totalDayTransactions = hourlyData.reduce(
        (sum, item) => sum + item.totalTransactions,
        0
      );

      return res.status(200).json({
        date: targetDate.toISOString().split("T")[0],
        hourlyBreakdown: hourlyData,
        totalDayIncome,
        totalDayTransactions,
        currency: "INR",
        unit: "paise",
      });
    } catch (error) {
      console.error("Error fetching hourly income:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /:restaurantId/analytics/income/date-range
router.get(
  "/:restaurantId/analytics/income/date-range",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { startDate, endDate } = req.query;

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      // Validate date parameters
      if (!startDate || !endDate) {
        return res
          .status(400)
          .json({ message: "startDate and endDate are required" });
      }

      const start = new Date(startDate as string);
      const end = new Date(endDate as string);

      if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }

      // Set time boundaries
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);

      // Get daily breakdown for the range
      const result = await db
        .select({
          date: sql<string>`DATE(${payments.createdAt})`,
          totalIncome: sql<number>`COALESCE(SUM(${payments.amount}), 0)`,
          totalTransactions: sql<number>`COUNT(*)`,
        })
        .from(payments)
        .where(
          and(
            eq(payments.restaurantId, restaurantId),
            eq(payments.status, "success"),
            eq(payments.isRefund, false),
            gte(payments.createdAt, start),
            lte(payments.createdAt, end)
          )
        )
        .groupBy(sql`DATE(${payments.createdAt})`)
        .orderBy(sql`DATE(${payments.createdAt})`);

      // Calculate totals
      const totalIncome = result.reduce((sum, item) => sum + item.totalIncome, 0);
      const totalTransactions = result.reduce(
        (sum, item) => sum + item.totalTransactions,
        0
      );

      return res.status(200).json({
        startDate: start.toISOString().split("T")[0],
        endDate: end.toISOString().split("T")[0],
        dailyBreakdown: result,
        totalIncome,
        totalTransactions,
        currency: "INR",
        unit: "paise",
      });
    } catch (error) {
      console.error("Error fetching date range income:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /:restaurantId/analytics/orders/insights - Order insights analytics
router.get(
  "/:restaurantId/analytics/orders/insights",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { period = "30" } = req.query; // days

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - parseInt(period as string));

      // Total orders
      const totalOrders = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(orders)
        .where(
          and(
            eq(orders.restaurantId, restaurantId),
            gte(orders.createdAt, startDate)
          )
        );

      // Average order value
      const avgOrderValue = await db
        .select({ avg: sql<number>`AVG(CAST(${orders.totalAmount} AS DECIMAL))` })
        .from(orders)
        .where(
          and(
            eq(orders.restaurantId, restaurantId),
            gte(orders.createdAt, startDate)
          )
        );

      // Order status distribution
      const orderStatusStats = await db
        .select({
          status: orders.status,
          count: sql<number>`COUNT(*)`,
        })
        .from(orders)
        .where(
          and(
            eq(orders.restaurantId, restaurantId),
            gte(orders.createdAt, startDate)
          )
        )
        .groupBy(orders.status);

      return res.status(200).json({
        period: `${period} days`,
        totalOrders: totalOrders[0]?.count || 0,
        averageOrderValue: avgOrderValue[0]?.avg || 0,
        orderStatusDistribution: orderStatusStats,
      });
    } catch (error) {
      console.error("Error fetching order insights:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /:restaurantId/analytics/peak-hours - Peak hours analytics
router.get(
  "/:restaurantId/analytics/peak-hours",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { period = "30" } = req.query; // days

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - parseInt(period as string));

      // Orders by hour
      const hourlyStats = await db
        .select({
          hour: sql<number>`EXTRACT(HOUR FROM ${orders.createdAt})`,
          count: sql<number>`COUNT(*)`,
        })
        .from(orders)
        .where(
          and(
            eq(orders.restaurantId, restaurantId),
            gte(orders.createdAt, startDate)
          )
        )
        .groupBy(sql`EXTRACT(HOUR FROM ${orders.createdAt})`)
        .orderBy(sql`EXTRACT(HOUR FROM ${orders.createdAt})`);

      // Reservations by hour
      const reservationStats = await db
        .select({
          hour: sql<number>`EXTRACT(HOUR FROM ${reservations.reservationDate})`,
          count: sql<number>`COUNT(*)`,
        })
        .from(reservations)
        .where(
          and(
            eq(reservations.restaurantId, restaurantId),
            gte(reservations.reservationDate, startDate)
          )
        )
        .groupBy(sql`EXTRACT(HOUR FROM ${reservations.reservationDate})`)
        .orderBy(sql`EXTRACT(HOUR FROM ${reservations.reservationDate})`);

      return res.status(200).json({
        period: `${period} days`,
        ordersByHour: hourlyStats,
        reservationsByHour: reservationStats,
      });
    } catch (error) {
      console.error("Error fetching peak hours:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /:restaurantId/analytics/popular-items - Popular menu items analytics
router.get(
  "/:restaurantId/analytics/popular-items",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { period = "30", limit = "10" } = req.query; // days, top N items

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - parseInt(period as string));

      // Popular items by quantity ordered
      const popularItems = await db
        .select({
          menuItemId: orderItems.menuItemId,
          itemName: menuItems.name,
          totalQuantity: sql<number>`SUM(${orderItems.quantity})`,
          totalRevenue: sql<number>`SUM(CAST(${orderItems.total} AS DECIMAL))`,
          orderCount: sql<number>`COUNT(DISTINCT ${orderItems.orderId})`,
        })
        .from(orderItems)
        .innerJoin(orders, eq(orderItems.orderId, orders.id))
        .innerJoin(menuItems, eq(orderItems.menuItemId, menuItems.id))
        .where(
          and(
            eq(orders.restaurantId, restaurantId),
            gte(orders.createdAt, startDate)
          )
        )
        .groupBy(orderItems.menuItemId, menuItems.name)
        .orderBy(sql`SUM(${orderItems.quantity}) DESC`)
        .limit(parseInt(limit as string));

      return res.status(200).json({
        period: `${period} days`,
        popularItems,
      });
    } catch (error) {
      console.error("Error fetching popular items:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /:restaurantId/analytics/reservations - Reservation analytics
router.get(
  "/:restaurantId/analytics/reservations",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { period = "30" } = req.query; // days

      // Check authentication
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Check authorization
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!hasAccess) {
        return res
          .status(403)
          .json({ message: "You do not have permission to view analytics" });
      }

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - parseInt(period as string));

      // Total reservations
      const totalReservations = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(reservations)
        .where(
          and(
            eq(reservations.restaurantId, restaurantId),
            gte(reservations.reservationDate, startDate)
          )
        );

      // Reservation status distribution
      const reservationStatusStats = await db
        .select({
          status: reservations.status,
          count: sql<number>`COUNT(*)`,
        })
        .from(reservations)
        .where(
          and(
            eq(reservations.restaurantId, restaurantId),
            gte(reservations.reservationDate, startDate)
          )
        )
        .groupBy(reservations.status);

      // Average party size
      const avgPartySize = await db
        .select({ avg: sql<number>`AVG(${reservations.partySize})` })
        .from(reservations)
        .where(
          and(
            eq(reservations.restaurantId, restaurantId),
            gte(reservations.reservationDate, startDate)
          )
        );

      return res.status(200).json({
        period: `${period} days`,
        totalReservations: totalReservations[0]?.count || 0,
        averagePartySize: avgPartySize[0]?.avg || 0,
        reservationStatusDistribution: reservationStatusStats,
      });
    } catch (error) {
      console.error("Error fetching reservation analytics:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

export default router;
