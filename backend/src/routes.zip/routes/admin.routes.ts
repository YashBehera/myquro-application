import { Router } from "express";
import { isAdmin } from "../lib/checkRoles";
import { adminAuditLogs } from "../db/schema/admin-audit-logs";
import { restaurants } from "../db/schema/restaurants";
import { requireAuth } from "../auth/requireAuth";
import { db } from "../db/db";
import { nanoid } from "nanoid";
import { getClientIp } from "../lib/getIpAddress";
import { eq, sql, gte, and } from "drizzle-orm";
import { authUsers } from "../db/schema/auth-users";
import { reservations } from "../db/schema/reservations";
const router = Router();

/**
 * ✅ GET ALL RESTAURANTS (ADMIN ONLY)
 */
router.get("/restaurants", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    const restaurantList = await db.select().from(restaurants);

    // ✅ Correct IP extraction
    const ipAddress = getClientIp(req);

    // ✅ FIXED AUDIT LOG VALUES (ENUM SAFE + NO FAKE TARGET ID)
    const details = req.details;
    const adminAuditLog = {
      id: nanoid(),
      adminUserId: user.id,
      action: "VIEW_RESTAURANTS" as const,
      targetType: "restaurant",
      targetId: null, // ✅ NOT "all"
      ipAddress: ipAddress,
      userAgent: req.headers["user-agent"] as string | undefined,
      details: details,
    };

    await db.insert(adminAuditLogs).values(adminAuditLog);

    return res.status(200).json({ restaurants: restaurantList });
  } catch (err) {
    console.error("Error fetching restaurants:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});

/**
 * ✅ SUSPEND RESTAURANT
 */
router.patch("/restaurants/suspend/:id", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    const restaurantId = req.params.id;
    const { reason } = req.body;

    // ✅ LOGIC FIX: reason is now mandatory
    if (!reason || reason.trim().length < 5) {
      return res
        .status(400)
        .json({ message: "Valid suspension reason is required" });
    }

    const restaurant = await db
      .update(restaurants)
      .set({
        restaurantStatus: "suspended",
        suspendedAt: new Date(),
        suspendedReason: reason,
      })
      .where(eq(restaurants.id, restaurantId))
      .returning();

    if (restaurant.length === 0) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    // ✅ Correct IP extraction
    const ipAddress = getClientIp(req);

    // ✅ FIXED AUDIT LOG VALUES
    const adminAuditLog = {
      id: nanoid(),
      adminUserId: user.id,
      action: "SUSPEND_RESTAURANT" as const,
      targetType: "restaurant",
      targetId: restaurantId,
      ipAddress: ipAddress,
      userAgent: req.headers["user-agent"] as string | undefined,
      details: JSON.stringify({
        reason,
        previousStatus: "active",
        newStatus: "suspended",
      }),
    };

    await db.insert(adminAuditLogs).values(adminAuditLog);

    return res.status(200).json({ restaurant: restaurant[0] });
  } catch (err) {
    console.error("Error suspending restaurant:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});

/**
 * ✅ REACTIVATE RESTAURANT
 */
router.patch(
  "/restaurants/reactivate/:id",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const isAllowedUser = await isAdmin(user.id);

      if (!isAllowedUser) {
        return res.status(403).json("You are not authorized to do this");
      }

      const restaurantId = req.params.id;

      const restaurant = await db
        .update(restaurants)
        .set({
          restaurantStatus: "active",
          suspendedAt: null,
          suspendedReason: null,
        })
        .where(eq(restaurants.id, restaurantId))
        .returning();

      if (restaurant.length === 0) {
        return res.status(404).json({ message: "Restaurant not found" });
      }

      // ✅ Correct IP extraction
      const ipAddress = getClientIp(req);

      // ✅ FIXED AUDIT LOG VALUES
      const adminAuditLog = {
        id: nanoid(),
        adminUserId: user.id,
        action: "UNSUSPEND_RESTAURANT" as const,
        targetType: "restaurant",
        targetId: restaurantId,
        ipAddress: ipAddress,
        userAgent: req.headers["user-agent"] as string | undefined,
        details: JSON.stringify({
          previousStatus: "suspended",
          newStatus: "active",
        }),
      };

      await db.insert(adminAuditLogs).values(adminAuditLog);

      return res.status(200).json({ restaurant: restaurant[0] });
    } catch (err) {
      console.error("Error reactivating restaurant:", err);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);


// Update Restaurant Details
router.put("/restaurants/:id", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    const restaurantId = req.params.id;
    const { name, address, contactEmail } = req.body;

    const restaurant = await db
      .update(restaurants)
      .set({
        restaurantName: name,
        restaurantAddress: address,
        email: contactEmail,
      })
      .where(eq(restaurants.id, restaurantId))
      .returning();

    if (restaurant.length === 0) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    // ✅ Correct IP extraction
    const ipAddress = getClientIp(req);

    // ✅ FIXED AUDIT LOG VALUES
    const adminAuditLog = {
      id: nanoid(),
      adminUserId: user.id,
      action: "UPDATE_RESTAURANT" as const,
      targetType: "restaurant",
      targetId: restaurantId,
      ipAddress: ipAddress,
      userAgent: req.headers["user-agent"] as string | undefined,
      details: JSON.stringify({
        updatedFields: { name, address, contactEmail },
      }),
    };

    await db.insert(adminAuditLogs).values(adminAuditLog);

    return res.status(200).json({ restaurant: restaurant[0] });
  } catch (err) {
    console.error("Error updating restaurant:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});


// QR Generation for Admin
router.post("/tables/:tableId/qrcode", requireAuth, async (req: any, res) => {
  try {
    const { tableId } = req.params;
    const { restaurantId } = req.body;
    const user = req.user;

    const isAllowedUser = await isAdmin(user.id);
    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    // Get table & restaurant
    const table = await db
      .select()
      .from(tables)
      .where((
          eq(tables.id, tableId),
          eq(tables.restaurantId, restaurantId)
        )
      )
      .limit(1);

    if (table.length === 0) {
      return res.status(404).json({ message: "Table not found" });
    }

    // Generate a new QR token
    const qrToken = nanoid(32);

    // Step 1: Delete any existing QR code for the table
    await db.delete(tableQR).where(eq(tableQR.tableId, tableId));

    // Step 2: Insert the new QR code
    await db.insert(tableQR).values({
      id: nanoid(),
      restaurantId,
      tableId,
      qrToken,
      isLocked: false,
      createdAt: new Date(),
    });

    // Step 3: Generate the QR code image
    const scanUrl = `${process.env.BACKEND_URL}/api/qr/scan/${qrToken}`;

    // Return the response
    return res.status(201).json({
      message: "QR code generated successfully",
      qrToken,
      scanUrl,
    });
  } catch (error) {
    console.error("Error generating QR code:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});


// Admin analytics

router.get("/analytics/restaurants/count", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    const result = await db
      .select()
      .from(restaurants);

    const totalRestaurants = result.length;

    return res.status(200).json({ totalRestaurants });
  } catch (err) {
    console.error("Error fetching restaurant count:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/analytics/orders/count", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    const totalOrders = await db.select().from(orders); // Replace with actual DB query
    const countTotalOrders = totalOrders.length;
    return res.status(200).json({ countTotalOrders });
  } catch (err) {
    console.error("Error fetching order count:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/analytics/failed-payments", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    const failedPayments = await db
      .select()
      .from(payments)
      .where(eq(payments.status, "failed"));

    return res.status(200).json({ failedPayments });
  } catch (err) {
    console.error("Error fetching failed payments:", err);
    return res.status(500).json({ message: "Internal server error" });
  }

});

/**
 * ✅ ADMIN DASHBOARD OVERVIEW
 */
router.get("/dashboard/overview", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    // Today's date range
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Total restaurants
    const totalRestaurants = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(restaurants);

    // Active restaurants
    const activeRestaurants = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(restaurants)
      .where(eq(restaurants.restaurantStatus, "active"));

    // Total users (customers + restaurant users)
    const totalUsers = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(authUsers);

    // Today's orders
    const todayOrders = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(orders)
      .where(
        and(
          gte(orders.createdAt, today),
          sql`${orders.createdAt} < ${tomorrow}`
        )
      );

    // Today's revenue
    const todayRevenue = await db
      .select({ revenue: sql<number>`COALESCE(SUM(CAST(${orders.totalAmount} AS DECIMAL)), 0)` })
      .from(orders)
      .where(
        and(
          gte(orders.createdAt, today),
          sql`${orders.createdAt} < ${tomorrow}`
        )
      );

    // Today's reservations
    const todayReservations = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(reservations)
      .where(
        and(
          gte(reservations.reservationDate, today),
          sql`${reservations.reservationDate} < ${tomorrow}`
        )
      );

    // Recent orders (last 10)
    const recentOrders = await db
      .select({
        id: orders.id,
        restaurantId: orders.restaurantId,
        status: orders.status,
        totalAmount: orders.totalAmount,
        createdAt: orders.createdAt,
        customerName: orders.customerName,
      })
      .from(orders)
      .orderBy(sql`${orders.createdAt} DESC`)
      .limit(10);

    // Recent payments (last 10)
    const recentPayments = await db
      .select({
        id: payments.id,
        amount: payments.amount,
        status: payments.status,
        createdAt: payments.createdAt,
        restaurantId: payments.restaurantId,
      })
      .from(payments)
      .orderBy(sql`${payments.createdAt} DESC`)
      .limit(10);

    // System health metrics
    const failedPayments = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(payments)
      .where(eq(payments.status, "failed"));

    return res.status(200).json({
      overview: {
        totalRestaurants: totalRestaurants[0]?.count || 0,
        activeRestaurants: activeRestaurants[0]?.count || 0,
        totalUsers: totalUsers[0]?.count || 0,
        todayOrders: todayOrders[0]?.count || 0,
        todayRevenue: todayRevenue[0]?.revenue || 0,
        todayReservations: todayReservations[0]?.count || 0,
        failedPayments: failedPayments[0]?.count || 0,
      },
      recentActivity: {
        orders: recentOrders,
        payments: recentPayments,
      },
    });
  } catch (err) {
    console.error("Error fetching admin dashboard overview:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});

/**
 * ✅ ADMIN ANALYTICS - PLATFORM WIDE
 */
router.get("/analytics/platform", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const isAllowedUser = await isAdmin(user.id);
    const { period = "30" } = req.query; // days

    if (!isAllowedUser) {
      return res.status(403).json("You are not authorized to do this");
    }

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period as string));

    // Platform-wide order metrics
    const orderMetrics = await db
      .select({
        totalOrders: sql<number>`COUNT(*)`,
        totalRevenue: sql<number>`COALESCE(SUM(CAST(${orders.totalAmount} AS DECIMAL)), 0)`,
        avgOrderValue: sql<number>`AVG(CAST(${orders.totalAmount} AS DECIMAL))`,
      })
      .from(orders)
      .where(gte(orders.createdAt, startDate));

    // Order status distribution
    const orderStatusDist = await db
      .select({
        status: orders.status,
        count: sql<number>`COUNT(*)`,
      })
      .from(orders)
      .where(gte(orders.createdAt, startDate))
      .groupBy(orders.status);

    // Payment success rate
    const paymentMetrics = await db
      .select({
        status: payments.status,
        count: sql<number>`COUNT(*)`,
      })
      .from(payments)
      .where(gte(payments.createdAt, startDate))
      .groupBy(payments.status);

    // Restaurant performance (top 10 by revenue)
    const topRestaurants = await db
      .select({
        restaurantId: orders.restaurantId,
        restaurantName: restaurants.restaurantName,
        totalOrders: sql<number>`COUNT(${orders.id})`,
        totalRevenue: sql<number>`COALESCE(SUM(CAST(${orders.totalAmount} AS DECIMAL)), 0)`,
      })
      .from(orders)
      .innerJoin(restaurants, eq(orders.restaurantId, restaurants.id))
      .where(gte(orders.createdAt, startDate))
      .groupBy(orders.restaurantId, restaurants.restaurantName)
      .orderBy(sql`COALESCE(SUM(CAST(${orders.totalAmount} AS DECIMAL)), 0) DESC`)
      .limit(10);

    return res.status(200).json({
      period: `${period} days`,
      orderMetrics: orderMetrics[0],
      orderStatusDistribution: orderStatusDist,
      paymentStatusDistribution: paymentMetrics,
      topPerformingRestaurants: topRestaurants,
    });
  } catch (err) {
    console.error("Error fetching platform analytics:", err);
    return res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
