import { Router } from "express";
import { db } from "../db/db";
import { offers } from "../db/schema/offers";
import { requireAuth } from "../auth/requireAuth";
import { isRestaurantOwnerOrManager } from "../lib/checkRoles";
import { eq, and } from "drizzle-orm";

const router = Router();

// Get all offers for a restaurant
router.get("/:restaurantId", requireAuth, async (req: any, res) => {
  try {
    const { restaurantId } = req.params;
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. PERMISSION CHECK
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. GET OFFERS
    const restaurantOffers = await db
      .select()
      .from(offers)
      .where(eq(offers.restaurantId, restaurantId))
      .orderBy(offers.createdAt);

    // ✅ 4. SUCCESS RESPONSE
    res.status(200).json({ offers: restaurantOffers });
  } catch (error) {
    console.error("FETCH OFFERS ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Create a new offer
router.post("/:restaurantId", requireAuth, async (req: any, res) => {
  try {
    const { restaurantId } = req.params;
    const { description, discountPercentage } = req.body;
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. PERMISSION CHECK
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. VALIDATION
    if (!description || !discountPercentage) {
      return res.status(400).json({ message: "Description and discount percentage are required" });
    }

    if (isNaN(parseFloat(discountPercentage)) || parseFloat(discountPercentage) <= 0 || parseFloat(discountPercentage) > 100) {
      return res.status(400).json({ message: "Discount percentage must be a number between 1 and 100" });
    }

    // ✅ 4. CREATE OFFER
    const newOffer = await db
      .insert(offers)
      .values({
        id: crypto.randomUUID(),
        description,
        discountPercentage: discountPercentage.toString(),
        restaurantId,
        createdBy: user.id,
      })
      .returning();

    // ✅ 5. SUCCESS RESPONSE
    res.status(201).json({ offer: newOffer[0] });
  } catch (error) {
    console.error("CREATE OFFER ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Update an offer
router.patch("/:restaurantId/:offerId", requireAuth, async (req: any, res) => {
  try {
    const { restaurantId, offerId } = req.params;
    const { description, discountPercentage } = req.body;
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. PERMISSION CHECK
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. VALIDATION
    if (discountPercentage && (isNaN(parseFloat(discountPercentage)) || parseFloat(discountPercentage) <= 0 || parseFloat(discountPercentage) > 100)) {
      return res.status(400).json({ message: "Discount percentage must be a number between 1 and 100" });
    }

    // ✅ 4. UPDATE OFFER
    const updateData: any = {};
    if (description) updateData.description = description;
    if (discountPercentage) updateData.discountPercentage = discountPercentage.toString();

    const updatedOffer = await db
      .update(offers)
      .set(updateData)
      .where(and(eq(offers.id, offerId), eq(offers.restaurantId, restaurantId)))
      .returning();

    if (updatedOffer.length === 0) {
      return res.status(404).json({ message: "Offer not found" });
    }

    // ✅ 5. SUCCESS RESPONSE
    res.status(200).json({ offer: updatedOffer[0] });
  } catch (error) {
    console.error("UPDATE OFFER ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Delete an offer
router.delete("/:restaurantId/:offerId", requireAuth, async (req: any, res) => {
  try {
    const { restaurantId, offerId } = req.params;
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. PERMISSION CHECK
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. DELETE OFFER
    const deletedOffer = await db
      .delete(offers)
      .where(and(eq(offers.id, offerId), eq(offers.restaurantId, restaurantId)))
      .returning();

    if (deletedOffer.length === 0) {
      return res.status(404).json({ message: "Offer not found" });
    }

    // ✅ 4. SUCCESS RESPONSE
    res.status(200).json({ message: "Offer deleted successfully" });
  } catch (error) {
    console.error("DELETE OFFER ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;