import { Router } from "express";
import { db } from "../db/db";
import { restaurants } from "../db/schema/restaurants";
import { menuCategories } from "../db/schema/menu-categories";
import { menuItems } from "../db/schema/menu-items";
import { menuItemVariants } from "../db/schema/menu-item-variants";
import { and, eq } from "drizzle-orm";
import { requireAuth } from "../auth/requireAuth";
import { isRestaurantOwnerOrManager } from "../lib/checkRoles";
import { nanoid } from "nanoid";

const router = Router();

// Dev-only shortcut: allow activating a variant without auth for quick testing
if (process.env.NODE_ENV !== "production") {
  router.patch(
    "/:restaurantId/menu/items/:itemId/variants/:variantId/activate",
    async (req: any, res: any) => {
      try {
        const { restaurantId, itemId, variantId } = req.params;
        console.debug("Dev activate shortcut hit", { restaurantId, itemId, variantId });
        await db
          .update(menuItemVariants)
          .set({ isActive: true })
          .where(
            and(
              eq(menuItemVariants.id, variantId),
              eq(menuItemVariants.menuItemId, itemId)
            )
          );
        return res.status(200).json({ message: "Variant activated (dev override)" });
      } catch (error) {
        console.error("Dev activate shortcut error:", error);
        return res.status(500).json({ message: "Internal server error" });
      }
    }
  );
}

router.post(
  "/:restaurantId/menu/categories",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      const { name, description, display_order } = req.body;
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to add menu categories",
        });
      }
      const newCategory = {
        id: nanoid(),
        restaurantId,
        category: name,
        description,
        displayOrder: display_order,
      };
      await db.insert(menuCategories).values(newCategory);
      return res
        .status(201)
        .json({ message: "Menu category created", category: newCategory });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.post("/:restaurantId/menu/items", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { restaurantId } = req.params;
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    const { name, description, categoryId, imageURL, isVeg, additionalInfo } = req.body;

    console.log("CREATE MENU ITEM - User:", user?.id, "Restaurant:", restaurantId);
    console.log("CREATE MENU ITEM - Data:", { name, description, categoryId, isVeg, imageURL });

    if (!user || user.role !== "restaurant") {
      console.log("CREATE MENU ITEM - Auth failed");
      return res.status(401).json({ message: "Authentication required" });
    }

    if (!hasAccess) {
      console.log("CREATE MENU ITEM - Access denied");
      return res.status(403).json({
        message: "You do not have permission to add menu items",
      });
    }

    const newItem = {
      id: nanoid(),
      restaurantId,
      categoryId,
      name,
      description,
      imageURL,
      isVeg: isVeg !== undefined ? isVeg : true,
    };

    console.log("CREATE MENU ITEM - Inserting item:", newItem);
    await db.insert(menuItems).values(newItem);
    console.log("CREATE MENU ITEM - Item created successfully");
    return res
      .status(201)
      .json({ message: "Menu item created", item: newItem });
  } catch (error) {
    console.error("CREATE MENU ITEM ERROR:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.post(
  "/:restaurantId/menu/items/:itemId/variants",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      const { name, price, additionalInfo, imageURL } = req.body;

      console.log("CREATE VARIANT - User:", user?.id, "Restaurant:", restaurantId, "Item:", itemId);
      console.log("CREATE VARIANT - Data:", { name, price, imageURL, additionalInfo });

      if (!user || user.role !== "restaurant") {
        console.log("CREATE VARIANT - Auth failed");
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        console.log("CREATE VARIANT - Access denied");
        return res.status(403).json({
          message: "You do not have permission to add menu item variants",
        });
      }

      // Validate price - should be in paise (integer)
      if (
        price === undefined ||
        typeof price !== "number" ||
        price <= 0 ||
        !Number.isInteger(price)
      ) {
        console.log("CREATE VARIANT - Invalid price:", price);
        return res
          .status(400)
          .json({
            message: "Invalid price - must be a positive integer in paise",
          });
      }

      if (
        !additionalInfo ||
        typeof additionalInfo !== "object" ||
        Array.isArray(additionalInfo)
      ) {
        console.log("CREATE VARIANT - Invalid additionalInfo");
        return res.status(400).json({ message: "Invalid additionalInfo" });
      }

      const item = await db
        .select()
        .from(menuItems)
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        )
        .limit(1);

      if (!item.length) {
        console.log("CREATE VARIANT - Item not found");
        return res
          .status(404)
          .json({ message: "Menu item not found for this restaurant" });
      }

      const newVariant = {
        id: nanoid(),
        menuItemId: itemId,
        variantName: name,
        foodType: additionalInfo.foodType,
        portionSize: additionalInfo.portionSize,
        price, // price is already in paise (integer)
        imageURL,
      };

      console.log("CREATE VARIANT - Inserting variant:", newVariant);
      await db.insert(menuItemVariants).values(newVariant);
      console.log("CREATE VARIANT - Variant created successfully");
      return res
        .status(201)
        .json({ message: "Menu item variant created", variant: newVariant });
    } catch (error) {
      console.error("CREATE VARIANT ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.get("/:restaurantId/menu", async (req, res) => {
  try {
    const { restaurantId } = req.params;

    const categories = await db
      .select()
      .from(menuCategories)
      .where(
        and(
          eq(menuCategories.restaurantId, restaurantId),
          eq(menuCategories.isActive, true)
        )
      );

    const menu = [];

    for (const category of categories) {
      const items = await db
        .select()
        .from(menuItems)
        .where(
          and(
            eq(menuItems.categoryId, category.id),
            eq(menuItems.isActive, true)
          )
        );

      const itemsWithVariants = [];

      for (const item of items) {
        const variants = await db
          .select()
          .from(menuItemVariants)
          .where(
            and(
              eq(menuItemVariants.menuItemId, item.id),
              eq(menuItemVariants.isActive, true)
            )
          );

        // Variants already have price in paise (integer)
        itemsWithVariants.push({ ...item, is_available: item.isActive, isVeg: item.isVeg, variants: variants.map(v => ({ ...v, is_available: v.isActive })) });
      }

      menu.push({ id: category.id, name: category.category, items: itemsWithVariants });
    }

    return res.status(200).json({ categories: menu });
  } catch (error) {
    console.error("Error fetching menu:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.get(
  "/:restaurantId/menu/categories",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to view menu categories",
        });
      }

      const categories = await db
        .select({
          id: menuCategories.id,
          category: menuCategories.category,
          description: menuCategories.description,
          displayOrder: menuCategories.displayOrder,
          isActive: menuCategories.isActive,
          createdAt: menuCategories.createdAt,
          updatedAt: menuCategories.updatedAt,
        })
        .from(menuCategories)
        .where(eq(menuCategories.restaurantId, restaurantId))
        .orderBy(menuCategories.displayOrder);

      return res.status(200).json({ categories });
    } catch (error) {
      console.error("Error fetching menu categories:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/categories/:categoryId/deactivate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, categoryId } = req.params;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to deactivate menu categories",
        });
      }

      await db
        .update(menuCategories)
        .set({ isActive: false })
        .where(eq(menuCategories.id, categoryId));

      return res
        .status(200)
        .json({ message: "Menu category updated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/categories/:categoryId/activate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, categoryId } = req.params;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to activate menu categories",
        });
      }

      await db
        .update(menuCategories)
        .set({ isActive: true })
        .where(eq(menuCategories.id, categoryId));

      return res
        .status(200)
        .json({ message: "Menu category activated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/categories/:categoryId/update",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, categoryId } = req.params;
      const { name, description } = req.body;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to update menu categories",
        });
      }

      const updateData: any = {};
      if (name !== undefined) updateData.category = name;
      if (description !== undefined) updateData.description = description;

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }

      await db
        .update(menuCategories)
        .set(updateData)
        .where(
          and(
            eq(menuCategories.id, categoryId),
            eq(menuCategories.restaurantId, restaurantId)
          )
        );

      return res
        .status(200)
        .json({ message: "Menu category updated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/update",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;
      const { name, description, additionalInfo, imageURL, isVeg } = req.body;

      console.log("UPDATE MENU ITEM - User:", user?.id, "Restaurant:", restaurantId, "Item:", itemId);
      console.log("UPDATE MENU ITEM - Update data:", { name, description, imageURL, isVeg });

      if (
        additionalInfo &&
        (typeof additionalInfo !== "object" || Array.isArray(additionalInfo))
      ) {
        console.log("UPDATE MENU ITEM - Invalid additionalInfo");
        return res.status(400).json({ message: "Invalid additionalInfo" });
      }

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        console.log("UPDATE MENU ITEM - Auth failed");
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        console.log("UPDATE MENU ITEM - Access denied");
        return res.status(403).json({
          message: "You do not have permission to update menu items",
        });
      }

      const updateData: any = {};
      if (name !== undefined) updateData.name = name;
      if (description !== undefined) updateData.description = description;
      if (additionalInfo !== undefined)
        updateData.additionalInfo = additionalInfo;
      if (imageURL !== undefined) updateData.imageURL = imageURL;
      if (isVeg !== undefined) updateData.isVeg = isVeg;

      console.log("UPDATE MENU ITEM - Final update data:", updateData);

      if (Object.keys(updateData).length === 0) {
        console.log("UPDATE MENU ITEM - No fields to update");
        return res.status(400).json({ message: "No valid fields to update" });
      }

      await db
        .update(menuItems)
        .set(updateData)
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        );

      console.log("UPDATE MENU ITEM - Item updated successfully");
      return res
        .status(200)
        .json({ message: "Menu item updated successfully" });
    } catch (error) {
      console.error("UPDATE MENU ITEM ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/variants/:variantId/update",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId, variantId } = req.params;
      const { variantName, price, additionalInfo, imageURL } = req.body;

      console.log("UPDATE VARIANT - User:", user?.id, "Restaurant:", restaurantId, "Item:", itemId, "Variant:", variantId);
      console.log("UPDATE VARIANT - Data:", { variantName, price, imageURL, additionalInfo });

      // Validate price - should be in paise (integer)
      if (
        price !== undefined &&
        (typeof price !== "number" || price <= 0 || !Number.isInteger(price))
      ) {
        console.log("UPDATE VARIANT - Invalid price:", price);
        return res
          .status(400)
          .json({
            message: "Invalid price - must be a positive integer in paise",
          });
      }

      if (
        additionalInfo &&
        (typeof additionalInfo !== "object" || Array.isArray(additionalInfo))
      ) {
        console.log("UPDATE VARIANT - Invalid additionalInfo");
        return res.status(400).json({ message: "Invalid additionalInfo" });
      }

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        console.log("UPDATE VARIANT - Auth failed");
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        console.log("UPDATE VARIANT - Access denied");
        return res.status(403).json({
          message: "You do not have permission to update menu item variants",
        });
      }

      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.id, itemId));

      console.log("UPDATE VARIANT - Items found:", items.length);

      if (!items || items.length === 0) {
        console.log("UPDATE VARIANT - Item not found");
        return res.status(404).json({ message: "Menu item not found" });
      }

      if (items[0].restaurantId !== restaurantId) {
        console.log("UPDATE VARIANT - Restaurant mismatch");
        return res.status(403).json({
          message: "You do not have permission to update this variant",
        });
      }

      const updateData: any = {};
      if (variantName !== undefined) updateData.variantName = variantName;
      if (price !== undefined) updateData.price = price; // price is in paise (integer)
      if (imageURL !== undefined) updateData.imageURL = imageURL;

      if (additionalInfo) {
        if (additionalInfo.foodType !== undefined) {
          updateData.foodType = additionalInfo.foodType;
        }
        if (additionalInfo.portionSize !== undefined) {
          updateData.portionSize = additionalInfo.portionSize;
        }
      }

      console.log("UPDATE VARIANT - Update data:", updateData);
      await db
        .update(menuItemVariants)
        .set(updateData)
        .where(
          and(
            eq(menuItemVariants.id, variantId),
            eq(menuItemVariants.menuItemId, itemId)
          )
        );
      console.log("UPDATE VARIANT - Variant updated successfully");
      return res
        .status(200)
        .json({ message: "Menu item variant updated successfully" });
    } catch (error) {
      console.error("UPDATE VARIANT ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/deactivate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to deactivate menu items",
        });
      }

      await db
        .update(menuItems)
        .set({ isActive: false })
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        );

      return res
        .status(200)
        .json({ message: "Menu item deactivated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/activate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to activate menu items",
        });
      }

      await db
        .update(menuItems)
        .set({ isActive: true })
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        );

      return res
        .status(200)
        .json({ message: "Menu item activated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/variants/:variantId/deactivate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId, variantId } = req.params;

      console.log("DEACTIVATE VARIANT - User:", user?.id, "Restaurant:", restaurantId, "Item:", itemId, "Variant:", variantId);

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        console.log("DEACTIVATE VARIANT - Auth failed");
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        console.log("DEACTIVATE VARIANT - Access denied");
        return res.status(403).json({
          message:
            "You do not have permission to deactivate menu item variants",
        });
      }

      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.id, itemId));

      console.log("DEACTIVATE VARIANT - Items found:", items.length);

      if (!items || items.length === 0) {
        console.log("DEACTIVATE VARIANT - Item not found");
        return res.status(404).json({ message: "Menu item not found" });
      }

      if (items[0].restaurantId !== restaurantId) {
        console.log("DEACTIVATE VARIANT - Restaurant mismatch");
        return res.status(403).json({
          message: "You do not have permission to deactivate this variant",
        });
      }

      await db
        .update(menuItemVariants)
        .set({ isActive: false })
        .where(
          and(
            eq(menuItemVariants.id, variantId),
            eq(menuItemVariants.menuItemId, itemId)
          )
        );

      console.log("DEACTIVATE VARIANT - Variant deactivated successfully");
      return res
        .status(200)
        .json({ message: "Menu item variant deactivated successfully" });
    } catch (error) {
      console.error("DEACTIVATE VARIANT ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/variants/:variantId/activate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId, variantId } = req.params;

      console.log("ACTIVATE VARIANT - User:", user?.id, "Restaurant:", restaurantId, "Item:", itemId, "Variant:", variantId);

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        console.log("ACTIVATE VARIANT - Auth failed");
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        console.log("ACTIVATE VARIANT - Access denied");
        return res.status(403).json({
          message: "You do not have permission to activate menu item variants",
        });
      }

      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.id, itemId));

      console.log("ACTIVATE VARIANT - Items found:", items.length);

      if (!items || items.length === 0) {
        console.log("ACTIVATE VARIANT - Item not found");
        return res.status(404).json({ message: "Menu item not found" });
      }

      if (items[0].restaurantId !== restaurantId) {
        console.log("ACTIVATE VARIANT - Restaurant mismatch");
        return res.status(403).json({
          message: "You do not have permission to activate this variant",
        });
      }

      await db
        .update(menuItemVariants)
        .set({ isActive: true })
        .where(
          and(
            eq(menuItemVariants.id, variantId),
            eq(menuItemVariants.menuItemId, itemId)
          )
        );

      console.log("ACTIVATE VARIANT - Variant activated successfully");
      return res
        .status(200)
        .json({ message: "Menu item variant activated successfully" });
    } catch (error) {
      console.error("ACTIVATE VARIANT ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.delete(
  "/:restaurantId/menu/items/:itemId",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;

      console.log("DELETE MENU ITEM - User:", user?.id, "Restaurant:", restaurantId, "Item:", itemId);

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        console.log("DELETE MENU ITEM - Auth failed");
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        console.log("DELETE MENU ITEM - Access denied");
        return res.status(403).json({
          message: "You do not have permission to delete menu items",
        });
      }

      // First delete variants
      console.log("DELETE MENU ITEM - Deleting variants");
      await db
        .delete(menuItemVariants)
        .where(eq(menuItemVariants.menuItemId, itemId));

      // Then delete the item
      console.log("DELETE MENU ITEM - Deleting item");
      await db
        .delete(menuItems)
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        );

      console.log("DELETE MENU ITEM - Item deleted successfully");
      return res
        .status(200)
        .json({ message: "Menu item deleted successfully" });
    } catch (error) {
      console.error("DELETE MENU ITEM ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/categories/reorder",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { orderedCategoryIds } = req.body;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }
      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to reorder menu categories",
        });
      }

      for (let index = 0; index < orderedCategoryIds.length; index++) {
        const categoryId = orderedCategoryIds[index];
        await db
          .update(menuCategories)
          .set({ displayOrder: index })
          .where(
            and(
              eq(menuCategories.id, categoryId),
              eq(menuCategories.restaurantId, restaurantId)
            )
          );
      }

      return res
        .status(200)
        .json({ message: "Menu categories reordered successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.get("/:restaurantId/menu/manage", requireAuth, async (req: any, res) => {
  try {
    const { restaurantId } = req.params;
    const user = req.user;
    console.log("MENU MANAGE REQUEST - User:", user);
    console.log("MENU MANAGE REQUEST - Restaurant ID:", restaurantId);

    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    console.log("MENU MANAGE - Has access:", hasAccess);

    if (!user || user.role !== "restaurant") {
      console.log("MENU MANAGE - Auth failed, user role:", user?.role);
      return res.status(401).json({ message: "Authentication required" });
    }

    if (!hasAccess) {
      console.log("MENU MANAGE - Access denied for user:", user.id, "restaurant:", restaurantId);
      return res.status(403).json({
        message: "You do not have permission to view this menu",
      });
    }

    console.log("MENU MANAGE - Fetching categories for restaurant:", restaurantId);
    const categories = await db
      .select()
      .from(menuCategories)
      .where(eq(menuCategories.restaurantId, restaurantId));
    console.log("MENU MANAGE - Categories found:", categories.length);

    const menu = [];

    for (const category of categories) {
      console.log("MENU MANAGE - Processing category:", category.id, category.name);
      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.categoryId, category.id));
      console.log("MENU MANAGE - Items in category:", items.length);

      const itemsWithVariants = [];

      for (const item of items) {
        console.log("MENU MANAGE - Processing item:", item.id, item.name);
        const variants = await db
          .select()
          .from(menuItemVariants)
          .where(eq(menuItemVariants.menuItemId, item.id));
        console.log("MENU MANAGE - Variants for item:", variants.length);

        // Variants already have price in paise (integer)
        itemsWithVariants.push({ ...item, variants });
      }

      menu.push({ ...category, items: itemsWithVariants });
    }

    console.log("MENU MANAGE - Final menu structure:", menu.length, "categories");
    return res.status(200).json({ categories: menu });
  } catch (error) {
    console.error("MENU MANAGE ERROR:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
