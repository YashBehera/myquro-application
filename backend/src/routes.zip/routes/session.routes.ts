import { Router } from "express";
import { db } from "../db/db";
import { tableSession } from "../db/schema/table-session";
import { tableQR } from "../db/schema/table-qr";
import { tables } from "../db/schema/tables";
import { orders } from "../db/schema/orders";
import { orderItems } from "../db/schema/order-items";
import { menuItemVariants } from "../db/schema/menu-item-variants";
import { menuItems } from "../db/schema/menu-items";
import { nanoid } from "nanoid";
import { eq, and, desc } from "drizzle-orm";
import { auth } from "../auth/auth";
import { fromNodeHeaders } from "better-auth/node";

const router = Router();

// Optional auth middleware
const optionalAuth = async (req: any, res: any, next: any) => {
  try {
    const session = await auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    });
    if (session?.user) {
      req.user = session.user;
    }
    next();
  } catch (err) {
    next();
  }
};

// GET /validate-qr/:token - Validate QR token and return table/restaurant info
router.get("/validate-qr/:token", async (req, res) => {
  try {
    const { token } = req.params;

    console.log("Validating QR token:", token);

    // First check if QR token exists
    const qrExists = await db
      .select({ id: tableQR.id })
      .from(tableQR)
      .where(eq(tableQR.qrToken, token))
      .limit(1);

    if (qrExists.length === 0) {
      return res.status(404).json({ 
        success: false,
        message: "Invalid QR code" 
      });
    }

    // Find QR code record with table info
    const qrRecord = await db
      .select({
        qrId: tableQR.id,
        qrToken: tableQR.qrToken,
        tableId: tableQR.tableId,
        restaurantId: tableQR.restaurantId,
        isLocked: tableQR.isLocked,
        tableNumber: tables.tableNumber,
        tableCapacity: tables.capacity,
        tableStatus: tables.liveStatus,
      })
      .from(tableQR)
      .leftJoin(tables, eq(tableQR.tableId, tables.id))
      .where(eq(tableQR.qrToken, token))
      .limit(1);

    if (qrRecord.length === 0) {
      return res.status(404).json({ 
        success: false,
        message: "Invalid QR code" 
      });
    }

    const qr = qrRecord[0];

    if (qr.isLocked) {
      return res.status(403).json({ 
        success: false,
        message: "This QR code is currently locked" 
      });
    }

    if (qr.tableStatus === "occupied") {
      return res.status(409).json({ 
        success: false,
        message: "This table is currently occupied" 
      });
    }

    return res.json({
      success: true,
      data: {
        qrToken: qr.qrToken,
        tableId: qr.tableId,
        tableNumber: qr.tableNumber,
        capacity: qr.tableCapacity,
        restaurantId: qr.restaurantId,
      },
    });
  } catch (error: any) {
    console.error("Error validating QR:", error);
    return res.status(500).json({ 
      success: false,
      message: "Failed to validate QR code" 
    });
  }
});

// POST /create-session - Create a new table session
router.post("/create-session", optionalAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { tableId, restaurantId, qrToken } = req.body;

    console.log("Creating session:", { tableId, restaurantId, qrToken, userId: user?.id });

    if (!restaurantId) {
      return res.status(400).json({ 
        success: false,
        message: "Restaurant ID is required" 
      });
    }

    // Check if there's already an active session for this table
    if (tableId) {
      const existingSessions = await db
        .select()
        .from(tableSession)
        .where(
          and(
            eq(tableSession.tableId, tableId),
            eq(tableSession.status, "active")
          )
        )
        .limit(1);

      if (existingSessions.length > 0) {
        // Return existing session
        return res.json({
          success: true,
          sessionId: existingSessions[0].id,
          message: "Joined existing session",
          data: existingSessions[0],
        });
      }
    }

    // Lock the table if tableId is provided
    if (tableId) {
      await db
        .update(tables)
        .set({ 
          status: "occupied",
          updatedAt: new Date()
        })
        .where(eq(tables.id, tableId));
      
      console.log(`Table ${tableId} locked (status: occupied)`);
    }

    // Create new session
    const sessionId = nanoid();
    const newSession = {
      id: sessionId,
      tableId: tableId || null,
      restaurantId,
      qrToken: qrToken || null,
      status: "active" as const,
      paymentStatus: "unpaid" as const,
      createdByUserId: user?.id || null,
      startedAt: new Date(),
      endedAt: null,
      discountPercentage: 0,
      totalAmount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await db.insert(tableSession).values(newSession);

    // Update table status to occupied if tableId provided
    if (tableId) {
      await db
        .update(tables)
        .set({ status: "occupied", updatedAt: new Date() })
        .where(eq(tables.id, tableId));
    }

    console.log("Session created:", sessionId);

    return res.json({
      success: true,
      sessionId,
      message: "Session created successfully",
      data: newSession,
    });
  } catch (error: any) {
    console.error("Error creating session:", error);
    return res.status(500).json({ 
      success: false,
      message: "Failed to create session" 
    });
  }
});

// GET /session/:sessionId - Get session details with orders
router.get("/session/:sessionId", async (req, res) => {
  try {
    const { sessionId } = req.params;

    console.log("Fetching session:", sessionId);

    // Get session details
    const sessionData = await db
      .select({
        sessionId: tableSession.id,
        tableId: tableSession.tableId,
        tableNumber: tables.tableNumber,
        restaurantId: tableSession.restaurantId,
        qrToken: tableSession.qrToken,
        status: tableSession.status,
        paymentStatus: tableSession.paymentStatus,
        discountPercentage: tableSession.discountPercentage,
        totalAmount: tableSession.totalAmount,
        startedAt: tableSession.startedAt,
        endedAt: tableSession.endedAt,
      })
      .from(tableSession)
      .leftJoin(tables, eq(tableSession.tableId, tables.id))
      .where(eq(tableSession.id, sessionId))
      .limit(1);

    if (sessionData.length === 0) {
      return res.status(404).json({ 
        success: false,
        message: "Session not found" 
      });
    }

    const session = sessionData[0];

    // Get all orders for this session
    const sessionOrders = await db
      .select({
        orderId: orders.id,
        orderStatus: orders.status,
        orderNotes: orders.notes,
        subtotal: orders.subtotal,
        discount: orders.discount,
        gst: orders.gst,
        grandTotal: orders.grandTotal,
        createdAt: orders.createdAt,
      })
      .from(orders)
      .where(eq(orders.tableSessionId, sessionId))
      .orderBy(desc(orders.createdAt));

    // Get all order items for these orders
    const orderIds = sessionOrders.map(o => o.orderId);
    let allItems: any[] = [];

    if (orderIds.length > 0) {
      allItems = await db
        .select({
          orderItemId: orderItems.id,
          orderId: orderItems.orderId,
          menuItemId: orderItems.menuItemId,
          menuItemName: menuItems.name,
          variantId: orderItems.menuItemVariantId,
          variantName: menuItemVariants.variantName,
          quantity: orderItems.quantity,
          unitPrice: orderItems.unitPrice,
          totalPrice: orderItems.totalPrice,
          itemStatus: orderItems.status,
          notes: orderItems.notes,
        })
        .from(orderItems)
        .leftJoin(menuItems, eq(orderItems.menuItemId, menuItems.id))
        .leftJoin(menuItemVariants, eq(orderItems.menuItemVariantId, menuItemVariants.id))
        .where(eq(orderItems.tableSessionId, sessionId));
    }

    // Group items by order
    const ordersWithItems = sessionOrders.map(order => ({
      ...order,
      items: allItems.filter(item => item.orderId === order.orderId),
    }));

    // Calculate session totals
    const sessionSubtotal = sessionOrders.reduce((sum, order) => sum + (order.subtotal || 0), 0);
    const sessionDiscount = sessionOrders.reduce((sum, order) => sum + (order.discount || 0), 0);
    const sessionGst = sessionOrders.reduce((sum, order) => sum + (order.gst || 0), 0);
    const sessionGrandTotal = sessionOrders.reduce((sum, order) => sum + (order.grandTotal || 0), 0);

    return res.json({
      success: true,
      data: {
        session: {
          ...session,
          calculatedSubtotal: sessionSubtotal,
          calculatedDiscount: sessionDiscount,
          calculatedGst: sessionGst,
          calculatedGrandTotal: sessionGrandTotal,
        },
        orders: ordersWithItems,
        summary: {
          totalOrders: sessionOrders.length,
          totalItems: allItems.length,
          subtotal: sessionSubtotal,
          discount: sessionDiscount,
          gst: sessionGst,
          grandTotal: sessionGrandTotal,
        },
      },
    });
  } catch (error: any) {
    console.error("Error fetching session:", error);
    return res.status(500).json({ 
      success: false,
      message: "Failed to fetch session details" 
    });
  }
});

// GET /active-session/:restaurantId - Get active session for a user at a restaurant
router.get("/active-session/:restaurantId", optionalAuth, async (req: any, res) => {
  try {
    const { restaurantId } = req.params;
    const { tableId } = req.query;

    console.log("Finding active session:", { restaurantId, tableId });

    let whereConditions: any[] = [
      eq(tableSession.restaurantId, restaurantId),
      eq(tableSession.status, "active"),
    ];

    if (tableId) {
      whereConditions.push(eq(tableSession.tableId, tableId as string));
    }

    const activeSessions = await db
      .select({
        sessionId: tableSession.id,
        tableId: tableSession.tableId,
        tableNumber: tables.tableNumber,
        status: tableSession.status,
        startedAt: tableSession.startedAt,
      })
      .from(tableSession)
      .leftJoin(tables, eq(tableSession.tableId, tables.id))
      .where(and(...whereConditions))
      .orderBy(desc(tableSession.startedAt))
      .limit(1);

    if (activeSessions.length === 0) {
      return res.json({
        success: true,
        sessionId: null,
        message: "No active session found",
      });
    }

    return res.json({
      success: true,
      sessionId: activeSessions[0].sessionId,
      data: activeSessions[0],
    });
  } catch (error: any) {
    console.error("Error finding active session:", error);
    return res.status(500).json({ 
      success: false,
      message: "Failed to find active session" 
    });
  }
});

// GET /available-tables/:restaurantId - Get available tables for a restaurant
router.get("/available-tables/:restaurantId", async (req, res) => {
  try {
    const { restaurantId } = req.params;

    console.log("Fetching available tables for restaurant:", restaurantId);

    const availableTables = await db
      .select({
        tableId: tables.id,
        tableNumber: tables.tableNumber,
        capacity: tables.capacity,
        status: tables.status,
        location: tables.location,
      })
      .from(tables)
      .where(
        and(
          eq(tables.restaurantId, restaurantId),
          eq(tables.status, "available")
        )
      )
      .orderBy(tables.tableNumber);

    return res.json({
      success: true,
      data: availableTables,
    });
  } catch (error: any) {
    console.error("Error fetching available tables:", error);
    return res.status(500).json({ 
      success: false,
      message: "Failed to fetch available tables" 
    });
  }
});

// PUT /close-session/:sessionId - Close a table session
router.put("/close-session/:sessionId", optionalAuth, async (req: any, res) => {
  try {
    const { sessionId } = req.params;
    const { paymentStatus } = req.body; // Accept optional payment status from request

    console.log("Closing session:", sessionId, "Payment Status:", paymentStatus);

    // Get session details
    const sessionData = await db
      .select()
      .from(tableSession)
      .where(eq(tableSession.id, sessionId))
      .limit(1);

    if (sessionData.length === 0) {
      return res.status(404).json({ 
        success: false,
        message: "Session not found" 
      });
    }

    const session = sessionData[0];

    // Validate payment status before closing
    const finalPaymentStatus = paymentStatus || session.paymentStatus;
    
    if (finalPaymentStatus === "unpaid") {
      return res.status(400).json({ 
        success: false,
        message: "Cannot close session with unpaid status. Please update payment status first."
      });
    }

    // Update session status
    await db
      .update(tableSession)
      .set({
        status: "closed",
        paymentStatus: finalPaymentStatus,
        endedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(tableSession.id, sessionId));

    // Update table status to available and unlock it
    if (session.tableId) {
      await db
        .update(tables)
        .set({ status: "available", updatedAt: new Date() })
        .where(eq(tables.id, session.tableId));
      
      console.log(`Table ${session.tableId} unlocked and set to available`);
    }

    console.log("Session closed:", sessionId);

    return res.json({
      success: true,
      message: "Session closed successfully",
    });
  } catch (error: any) {
    console.error("Error closing session:", error);
    return res.status(500).json({ 
      success: false,
      message: "Failed to close session" 
    });
  }
});

// PUT /update-payment-status/:sessionId - Update payment status of a session
router.put("/update-payment-status/:sessionId", optionalAuth, async (req: any, res) => {
  try {
    const { sessionId } = req.params;
    const { paymentStatus } = req.body; // 'unpaid' | 'partial' | 'paid'

    if (!paymentStatus || !['unpaid', 'partial', 'paid'].includes(paymentStatus)) {
      return res.status(400).json({ 
        success: false,
        message: "Invalid payment status. Must be 'unpaid', 'partial', or 'paid'" 
      });
    }

    console.log("Updating payment status for session:", sessionId, "to:", paymentStatus);

    // Get session details
    const sessionData = await db
      .select()
      .from(tableSession)
      .where(eq(tableSession.id, sessionId))
      .limit(1);

    if (sessionData.length === 0) {
      return res.status(404).json({ 
        success: false,
        message: "Session not found" 
      });
    }

    const session = sessionData[0];

    if (session.status === "closed") {
      return res.status(400).json({ 
        success: false,
        message: "Cannot update payment status of a closed session" 
      });
    }

    // Update payment status
    await db
      .update(tableSession)
      .set({
        paymentStatus,
        updatedAt: new Date(),
      })
      .where(eq(tableSession.id, sessionId));

    console.log("Payment status updated:", sessionId, "->", paymentStatus);

    return res.json({
      success: true,
      message: "Payment status updated successfully",
      data: {
        sessionId,
        paymentStatus,
      }
    });
  } catch (error: any) {
    console.error("Error updating payment status:", error);
    return res.status(500).json({ 
      success: false,
      message: "Failed to update payment status" 
    });
  }
});

export default router;
