import { Router } from "express";
import { db } from "../db/db";
import { orders } from "../db/schema/orders";
import { orderItems } from "../db/schema/order-items";
import { menuItemVariants } from "../db/schema/menu-item-variants";
import { menuItems } from "../db/schema/menu-items";
import { tableSession } from "../db/schema/table-session";
import { tables } from "../db/schema/tables";
import { restaurantManagers } from "../db/schema/restaurant-managers";
import { nanoid } from "nanoid";
import { eq, and, inArray } from "drizzle-orm";
import { auth } from "../auth/auth";
import { fromNodeHeaders } from "better-auth/node";
import { requireAuth } from "../auth/requireAuth";
import { sendNotification } from "../lib/sendNotification";
import { verifyTableSession } from "../lib/verifyTableSession";
import {
  calculateSubtotal,
  calculateDiscount,
  calculateTaxableBase,
  calculateGST,
  calculateGrandTotal,
} from "../lib/billing";
import { isRestaurantOwnerOrManager } from "../lib/checkRoles";

const router = Router();

// Optional auth middleware
const optionalAuth = async (req: any, res: any, next: any) => {
  try {
    const session = await auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    });
    if (session?.user) {
      req.user = session.user;
    }
    next();
  } catch (err) {
    next();
  }
};

// POST /make-order
router.post("/make-order", async (req: any, res) => {
  try {
    console.log("MAKE ORDER REQUEST - Body:", JSON.stringify(req.body, null, 2));
    console.log("MAKE ORDER REQUEST - User:", req.user?.id || "No user");

    const user = req.user;
    const { tableSessionId, restaurantId, notes, items } = req.body;

    console.log("MAKE ORDER - Parsed data:", {
      tableSessionId,
      restaurantId,
      notes,
      itemsCount: items?.length || 0
    });

    // Validate request body
    if (!Array.isArray(items) || items.length === 0) {
      console.log("MAKE ORDER - Validation failed: Invalid items array");
      return res.status(400).json({ message: "Invalid order payload" });
    }

    console.log("MAKE ORDER - Items validation passed");

    // Generate order ID
    const orderId = nanoid();
    console.log("MAKE ORDER - Generated order ID:", orderId);

    // Fetch menu item variant prices
    console.log("MAKE ORDER - Fetching variant prices for items:", items.map(item => item.menuItemVariantId));
    const variantIds = items.map(item => item.menuItemVariantId);
    const variants = await db.select({
      id: menuItemVariants.id,
      price: menuItemVariants.price,
      menuItemId: menuItemVariants.menuItemId
    })
    .from(menuItemVariants)
    .where(inArray(menuItemVariants.id, variantIds));

    console.log("MAKE ORDER - Fetched variants:", variants);

    // Create items with prices for billing calculation
    const itemsWithPrices = items.map(item => {
      const variant = variants.find(v => v.id === item.menuItemVariantId);
      if (!variant) {
        throw new Error(`Menu item variant ${item.menuItemVariantId} not found`);
      }
      return {
        unitPrice: variant.price,
        quantity: item.quantity
      };
    });

    console.log("MAKE ORDER - Items with prices for calculation:", itemsWithPrices);

    // Calculate totals
    const subtotal = calculateSubtotal(itemsWithPrices);
    const discount = calculateDiscount(subtotal, 0);
    const taxableBase = calculateTaxableBase(subtotal, discount);
    const gst = calculateGST(taxableBase, 0);
    const grandTotal = calculateGrandTotal(taxableBase, gst);

    console.log("MAKE ORDER - Calculated totals:", {
      subtotal,
      discount,
      taxableBase,
      gst,
      grandTotal
    });

    // Handle table session - create dummy session for direct orders
    let finalTableSessionId = tableSessionId;
    if (!tableSessionId) {
      console.log("MAKE ORDER - No table session provided, creating dummy session for direct order");
      const dummySessionId = nanoid();
      const dummySession = {
        id: dummySessionId,
        restaurantId,
        tableId: null,
        qrToken: null,
        status: "active" as const,
        startedAt: new Date(),
        endedAt: null,
        totalAmount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      await db.insert(tableSession).values(dummySession);
      console.log("MAKE ORDER - Created dummy table session:", dummySessionId);
      finalTableSessionId = dummySessionId;
    }

    // Create order data
    const orderData = {
      id: orderId,
      placedByUserId: user?.id || null,
      restaurantId,
      tableSessionId: finalTableSessionId,
      status: "placed",
      subtotal,
      discount,
      gst,
      grandTotal,
      notes: notes || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    console.log("MAKE ORDER - Order data to insert:", orderData);

    // Insert order
    console.log("MAKE ORDER - Inserting order into database");
    const newOrder = await db.insert(orders).values(orderData).returning();
    console.log("MAKE ORDER - Order inserted successfully:", newOrder);

    // Create order items
    console.log("MAKE ORDER - Creating order items data");
    const orderItemsData = items.map((item: any) => {
      const variant = variants.find(v => v.id === item.menuItemVariantId);
      if (!variant) {
        throw new Error(`Menu item variant ${item.menuItemVariantId} not found`);
      }
      return {
        id: nanoid(),
        orderId,
        menuItemId: item.menuItemId,
        menuItemVariantId: item.menuItemVariantId,
        tableSessionId: finalTableSessionId,
        restaurantId,
        quantity: item.quantity,
        unitPrice: variant.price,
        totalPrice: variant.price * item.quantity,
        notes: item.itemNotes || null,
      };
    });

    console.log("MAKE ORDER - Order items data:", orderItemsData);

    // Insert order items
    console.log("MAKE ORDER - Inserting order items into database");
    await db.insert(orderItems).values(orderItemsData);
    console.log("MAKE ORDER - Order items inserted successfully");

    // Return success response
    console.log("MAKE ORDER - Returning success response");
    res.status(201).json({
      order: newOrder[0],
      items: orderItemsData,
      message: "Order created successfully"
    });

  } catch (error) {
    console.error("MAKE ORDER ERROR:", error);
    console.error("MAKE ORDER ERROR - Stack:", error.stack);
    res.status(500).json({ message: "Internal server error" });
  }
});

// POST /make-order/restaurant


// GET /orders/:tableSessionId
router.get("/:tableSessionId", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const tableSessionId = req.params.tableSessionId;

    const isValidSession = await verifyTableSession(tableSessionId);
    if (!isValidSession) {
      return res
        .status(400)
        .json({ message: "Invalid or inactive table session" });
    }

    // Fetch the session once
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(eq(tableSession.id, tableSessionId))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ message: "Table session not found" });
    }

    const isCustomer = session.createdByUserId === user.id;

    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, session.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    const isAllowedUser = isCustomer || isManager;

    if (!isAllowedUser) {
      return res
        .status(403)
        .json({ message: "You are not authorized to view these orders" });
    }

    const ordersList = await db
      .select()
      .from(orders)
      .where(eq(orders.tableSessionId, tableSessionId));

    // ✅ Updated query to join with menuItems and menuItemVariants
    const orderItemsRaw = await db
      .select()
      .from(orderItems)
      .leftJoin(menuItems, eq(orderItems.menuItemId, menuItems.id))
      .leftJoin(
        menuItemVariants,
        eq(orderItems.menuItemVariantId, menuItemVariants.id)
      )
      .where(eq(orderItems.tableSessionId, tableSessionId));

    // ✅ Flatten the result to include names
    const orderItemsList = orderItemsRaw.map((row) => ({
      ...row.order_items,
      itemName: row.menu_items?.name,
      variantName: row.menu_item_variants?.variantName,
    }));

    // Attach items to their respective orders
    const ordersWithItems = ordersList.map((order) => {
      return {
        ...order,
        items: orderItemsList.filter(
          (item) => item.orderId === order.id && item.status !== "cancelled"
        ),
      };
    });

    return res.status(200).json({ orders: ordersWithItems });
  } catch (error) {
    console.error("Error fetching orders:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// PATCH /orders/:orderId/cancel
router.patch("/:orderId/cancel", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const orderId = req.params.orderId;

    const orderRow = (
      await db.select().from(orders).where(eq(orders.id, orderId)).limit(1)
    )[0];

    if (!orderRow) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (
      orderRow.status === "served" ||
      orderRow.status === "preparing" ||
      orderRow.status === "cancelled"
    ) {
      return res.status(400).json({ message: "Order cannot be cancelled" });
    }

    // Fetch session to enforce payment locks
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(eq(tableSession.id, orderRow.tableSessionId))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ message: "Table session not found" });
    }

    if (session.paymentStatus === "paid") {
      return res
        .status(403)
        .json({ message: "Payment already completed. Cannot cancel order." });
    }

    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, orderRow.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    const isAllowedUser = orderRow.placedByUserId === user.id || isManager;

    if (!isAllowedUser) {
      return res
        .status(403)
        .json({ message: "You are not authorized to cancel this order" });
    }

    await db
      .update(orders)
      .set({ status: "cancelled" })
      .where(eq(orders.id, orderId));

    await sendNotification(
      orderRow.restaurantId,
      `Order ${orderId} has been cancelled.`,
      "order-update"
    );

    return res.status(200).json({ message: "Order cancelled successfully" });
  } catch (error) {
    console.error("Error cancelling order:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// PATCH /orders/:orderId/items/update
router.patch("/:orderId/items/update", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const orderId = req.params.orderId;
    const { items } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: "Invalid items payload" });
    }

    if (!orderId) {
      return res.status(400).json({ message: "Order ID is required" });
    }

    // ✅ Fetch order
    const order = (
      await db.select().from(orders).where(eq(orders.id, orderId)).limit(1)
    )[0];

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    // ✅ Fetch session
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(and(eq(tableSession.id, order.tableSessionId)))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ message: "Table session not found" });
    }

    // ✅ HARD LOCKS
    if (session.paymentStatus === "paid") {
      return res
        .status(403)
        .json({ message: "Payment already completed. Cannot modify order." });
    }

    if (order.status !== "placed") {
      return res
        .status(403)
        .json({ message: "Order can no longer be modified" });
    }

    // ✅ Authorization: customer OR restaurant staff
    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, order.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    const isAllowedUser = order.placedByUserId === user.id || isManager;

    if (!isAllowedUser) {
      return res
        .status(403)
        .json({ message: "You are not authorized to update this order" });
    }

    // ✅ Process each item
    for (const item of items) {
      const {
        action,
        orderItemId,
        menuItemId,
        menuItemVariantId,
        quantity,
        itemNotes,
      } = item;

      // ---------- ADD ITEM ----------
      if (action === "add") {
        if (!menuItemVariantId || !quantity || quantity <= 0) {
          return res.status(400).json({ message: "Invalid add item payload" });
        }

        const variant = (
          await db
            .select()
            .from(menuItemVariants)
            .where(eq(menuItemVariants.id, menuItemVariantId))
            .limit(1)
        )[0];
        if (variant.menuItemId !== menuItemId) {
          return res
            .status(400)
            .json({ message: "Variant does not belong to this menu item" });
        }

        if (!variant || !variant.isActive || !variant.isAvailable) {
          return res
            .status(400)
            .json({ message: "Invalid or unavailable variant" });
        }

        const unitPriceSnapshot = variant.price; // already in paise
        const totalPrice = unitPriceSnapshot * quantity; // paise

        await db.insert(orderItems).values({
          id: nanoid(),
          orderId,
          tableSessionId: order.tableSessionId,
          restaurantId: order.restaurantId,

          menuItemId,
          menuItemVariantId,

          quantity,
          unitPrice: unitPriceSnapshot, // paise
          totalPrice, // paise

          notes: itemNotes,
          status: "placed",
        });
      }

      // ---------- UPDATE ITEM ----------
      if (action === "update") {
        if (!orderItemId || !quantity || quantity <= 0) {
          return res.status(400).json({ message: "Invalid update payload" });
        }

        const existingItem = (
          await db
            .select()
            .from(orderItems)
            .where(
              and(
                eq(orderItems.id, orderItemId),
                eq(orderItems.orderId, orderId)
              )
            )
            .limit(1)
        )[0];

        if (!existingItem) {
          return res.status(404).json({ message: "Order item not found" });
        }

        const newTotal = existingItem.unitPrice * quantity; // paise

        await db
          .update(orderItems)
          .set({
            quantity,
            totalPrice: newTotal,
            notes: itemNotes ?? existingItem.notes,
          })
          .where(eq(orderItems.id, orderItemId));
      }

      // ---------- REMOVE ITEM ----------
      if (action === "remove") {
        if (!orderItemId) {
          return res.status(400).json({ message: "Invalid remove payload" });
        }

        await db
          .update(orderItems)
          .set({
            status: "cancelled",
            quantity: 0,
            totalPrice: 0,
          })
          .where(eq(orderItems.id, orderItemId));
      }
    }

    // ✅ Recalculate order total (in paise)
    const updatedItems = await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, orderId));

    const newTotalAmountInPaise = updatedItems.reduce(
      (sum: number, item: any) => sum + (item.totalPrice || 0),
      0
    );

    return res.status(200).json({
      message: "Order items updated successfully",
      orderId,
      updatedTotal: newTotalAmountInPaise, // return in paise
    });
  } catch (error) {
    console.error("Error updating order items:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// PATCH /orders/:orderId/status
router.patch("/:orderId/status", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const orderId = req.params.orderId;
    const { status } = req.body;

    if (
      !status ||
      !["placed", "preparing", "served", "cancelled"].includes(status)
    ) {
      return res.status(400).json({ message: "Invalid status value" });
    }

    const orderRow = (
      await db.select().from(orders).where(eq(orders.id, orderId)).limit(1)
    )[0];

    const validTransitions: Record<string, string[]> = {
      placed: ["preparing", "cancelled"],
      preparing: ["served"],
      served: [],
      cancelled: [],
    };

    if (!orderRow) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (!validTransitions[orderRow.status].includes(status)) {
      return res.status(400).json({
        message: `Invalid status transition from ${orderRow.status} to ${status}`,
      });
    }

    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, orderRow.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    if (!isManager) {
      return res
        .status(403)
        .json({ message: "You are not authorized to update order status" });
    }

    // Update the order status
    const orderStatus = await db.update(orders).set({ status }).where(eq(orders.id, orderId));

    // If the status is changed to "served", calculate billing details
    if (status === "served") {
      // 1. Update all items in this order to 'served' so they are included in calculation
      await db
        .update(orderItems)
        .set({ status: "served" })
        .where(eq(orderItems.orderId, orderId));

      const session = (
        await db
          .select()
          .from(tableSession)
          .where(eq(tableSession.id, orderRow.tableSessionId))
          .limit(1)
      )[0];

      if (!session) {
        return res.status(404).json({ message: "Table session not found" });
      }

      // 2. Fetch ALL served items for this SESSION (not just this order)
      const sessionItems = await db
        .select({
          unitPrice: orderItems.unitPrice,
          quantity: orderItems.quantity,
        })
        .from(orderItems)
        .where(
          and(
            eq(orderItems.tableSessionId, session.id),
            eq(orderItems.status, "served")
          )
        );

      // 3. Calculate billing details
      const subtotal = calculateSubtotal(sessionItems);
      const discountAmount = calculateDiscount(
        subtotal,
        session.discountPercentage || 0
      );
      const taxableBase = calculateTaxableBase(subtotal, discountAmount);

      // Use active gstRate, fallback to 0
      const currentGstRate = session.gstRate;
      const gstAmount = calculateGST(taxableBase, currentGstRate);

      const grandTotal = calculateGrandTotal(taxableBase, gstAmount);

      // 4. Update the table session with billing details
      await db
        .update(tableSession)
        .set({
          subtotal,
          discountAmount,
          taxableBase,
          gstAmount,
          grandTotal,
        })
        .where(eq(tableSession.id, session.id));
    }

    // Send notification about order status update
      await sendNotification(
        orderRow.restaurantId,
        `Order ${orderId} has been ${orderStatus}.`,
        "order-update"
      );

    return res
      .status(200)
      .json({ message: "Order status updated successfully" });
  } catch (error) {
    console.error("Error updating order status:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// GET /:userId/user-orders
router.get("/:userId/user-orders", requireAuth, async (req: any, res) => {
  try {
    const userId = req.params.userId;

    if (req.user.id !== userId) {
      return res
        .status(403)
        .json({ message: "You are not authorized to view these orders" });
    }

    const userOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.placedByUserId, userId));

    return res.status(200).json({ orders: userOrders });
  } catch (error) {
    console.error("Error fetching user orders:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// GET restaurant orders for managers
router.get(
  "/restaurant/:restaurantId/manager-orders",
  requireAuth,
  async (req: any, res) => {
    try {
      const restaurantId = req.params.restaurantId;
      const user = req.user;

      const isAllowedUser = await isRestaurantOwnerOrManager(
        user.id,
        restaurantId
      );
      if (!isAllowedUser) {
        return res
          .status(403)
          .json({ message: "You are not authorized to view these orders" });
      }

      const restaurantOrders = await db
        .select({
          id: orders.id,
          tableSessionId: orders.tableSessionId,
          restaurantId: orders.restaurantId,
          tableId: orders.tableId,
          placedByUserId: orders.placedByUserId,
          notes: orders.notes,
          status: orders.status,
          subtotal: orders.subtotal,
          discount: orders.discount,
          gst: orders.gst,
          grandTotal: orders.grandTotal,
          createdAt: orders.createdAt,
          updatedAt: orders.updatedAt,
          // Join with tables to get table number
          tableNumber: tables.tableNumber,
        })
        .from(orders)
        .leftJoin(tables, eq(orders.tableId, tables.id))
        .where(eq(orders.restaurantId, restaurantId));

      // Get order items for each order
      const orderIds = restaurantOrders.map(order => order.id);
      const allOrderItems = await db
        .select({
          id: orderItems.id,
          orderId: orderItems.orderId,
          menuItemId: orderItems.menuItemId,
          menuItemVariantId: orderItems.menuItemVariantId,
          quantity: orderItems.quantity,
          unitPrice: orderItems.unitPrice,
          totalPrice: orderItems.totalPrice,
          notes: orderItems.notes,
          status: orderItems.status,
          // Join with menu_item_variants to get variant name
          variantName: menuItemVariants.variantName,
        })
        .from(orderItems)
        .leftJoin(menuItemVariants, eq(orderItems.menuItemVariantId, menuItemVariants.id))
        .where(inArray(orderItems.orderId, orderIds));

      // Group items by order
      const ordersWithItems = restaurantOrders.map(order => ({
        ...order,
        totalAmount: order.grandTotal || 0,
        items: allOrderItems.filter(item => item.orderId === order.id),
      }));

      return res.status(200).json({ orders: ordersWithItems });
    } catch (error) {
      console.error("Error fetching restaurant orders:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// POST /manual-order - Create order manually for restaurant staff
router.post("/manual-order", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const {
      restaurantId,
      tableId,
      customerName,
      customerPhone,
      items,
      notes,
      discountPercentage,
      paymentMethod
    } = req.body;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. PERMISSION CHECK
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. VALIDATION
    if (!restaurantId || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: "Restaurant ID and items are required" });
    }

    if (!customerName || !customerPhone) {
      return res.status(400).json({ message: "Customer name and phone are required" });
    }

    // ✅ 4. CREATE TABLE SESSION (if tableId provided)
    let sessionId = null;
    if (tableId) {
      const newSession = await db
        .insert(tableSession)
        .values({
          id: nanoid(),
          tableId,
          restaurantId,
          status: "active",
          startedAt: new Date(),
          discountPercentage: discountPercentage ? discountPercentage.toString() : "0",
        })
        .returning();
      sessionId = newSession[0].id;
    }

    // ✅ 5. CALCULATE ORDER TOTALS
    let subtotal = 0;
    const orderItemsData = [];

    for (const item of items) {
      // Get variant price (required)
      if (!item.variantId) {
        return res.status(400).json({ message: `Variant ID is required for item ${item.menuItemId}` });
      }

      const variant = await db
        .select()
        .from(menuItemVariants)
        .where(eq(menuItemVariants.id, item.variantId))
        .limit(1);

      if (variant.length === 0) {
        return res.status(404).json({ message: `Menu item variant ${item.variantId} not found` });
      }

      const itemPrice = variant[0].price;
      const itemTotal = itemPrice * item.quantity;
      subtotal += itemTotal;

      orderItemsData.push({
        id: nanoid(),
        orderId: "", // Will be set after order creation
        menuItemId: item.menuItemId,
        variantId: item.variantId || null,
        quantity: item.quantity,
        price: itemPrice.toString(),
        total: itemTotal.toString(),
        notes: item.notes || null,
      });
    }

    // ✅ 6. CALCULATE DISCOUNTS AND TAXES
    const discount = discountPercentage ? calculateDiscount(subtotal, parseFloat(discountPercentage)) : 0;
    const taxableBase = calculateTaxableBase(subtotal, discount);
    const gst = calculateGST(taxableBase, 0);
    const grandTotal = calculateGrandTotal(taxableBase, gst);

    // ✅ 7. CREATE ORDER
    const orderId = nanoid();
    const newOrder = await db
      .insert(orders)
      .values({
        id: orderId,
        restaurantId,
        tableSessionId: sessionId,
        placedByUserId: user.id,
        status: "confirmed",
        totalAmount: grandTotal.toString(),
        subtotal: subtotal.toString(),
        discount: discount.toString(),
        gst: gst.toString(),
        notes,
        customerName,
        customerPhone,
        paymentMethod: paymentMethod || "cash",
        createdAt: new Date(),
      })
      .returning();

    // ✅ 8. CREATE ORDER ITEMS
    for (const item of orderItemsData) {
      item.orderId = orderId;
      await db.insert(orderItems).values(item);
    }

    // ✅ 9. SUCCESS RESPONSE
    res.status(201).json({
      order: newOrder[0],
      items: orderItemsData,
      message: "Order created successfully"
    });
  } catch (error) {
    console.error("MANUAL ORDER CREATION ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
