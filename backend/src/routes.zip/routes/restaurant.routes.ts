import { Router } from "express";
import { db } from "../db/db";
import { restaurants } from "../db/schema/restaurants";
import { requireAuth } from "../auth/requireAuth";
import {
  isRestaurantOwnerOrManager,
  getRestaurantRole,
} from "../lib/checkRoles";
import { eq, and, gte, sql } from "drizzle-orm";
import { reservations } from "../db/schema/reservations";
import { tables } from "../db/schema/tables";
import { tableSession } from "../db/schema/table-session";

const router = Router();

// Get all restaurants
router.get("/", async (req: any, res) => {
  try {
    const allRestaurants = await db.select().from(restaurants);
    res.status(200).json({ restaurants: allRestaurants });
  } catch (error) {
    console.error("FETCH RESTAURANTS ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get my restaurant with role-based access control
router.get("/my-restaurant", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    console.log("MY RESTAURANT REQUEST - User:", user);

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      console.log("MY RESTAURANT - Auth failed, user role:", user?.role);
      return res.status(401).json({ message: "Authentication required" });
    }

    console.log("MY RESTAURANT - User ID:", user.id);

    // ✅ 2. VERIFY OWNER OR MANAGER ACCESS
    const restaurant = await db
      .select()
      .from(restaurants)
      .where(eq(restaurants.ownerId, user.id))
      .limit(1);

    console.log("MY RESTAURANT - Query result:", restaurant);

    if (restaurant.length === 0) {
      console.log("MY RESTAURANT - No restaurant found for user:", user.id);
      return res.status(404).json({ message: "Restaurant not found" });
    }

    const hasAccess = await isRestaurantOwnerOrManager(
      user.id,
      restaurant[0].id
    );
    console.log("MY RESTAURANT - Has access:", hasAccess);
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. SUCCESS RESPONSE
    return res.status(200).json({ restaurant: restaurant[0] });
  } catch (error) {
    console.error("FETCH MY RESTAURANT ERROR:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// Get restaurant by ID
router.get("/:id", async (req: any, res) => {
  try {
    const { id } = req.params;
    const restaurant = await db
      .select()
      .from(restaurants)
      .where(eq(restaurants.id, id))
      .limit(1);

    if (restaurant.length === 0) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    res.status(200).json({ restaurant: restaurant[0] });
  } catch (error) {
    console.error("FETCH RESTAURANT ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get restaurant stats for dashboard
router.get("/:id/stats", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const restaurantId = req.params.id;

    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    if (!hasAccess) {
      return res.status(403).json({
        message: "You do not have permission to view restaurant stats",
      });
    }

    // For now, return mock stats. In a real app, you'd calculate from orders table
    const stats = {
      totalOrders: 0,
      totalRevenue: 0,
      activeOrders: 0,
      averageRating: 0
    };

    res.status(200).json(stats);
  } catch (error) {
    console.error("FETCH RESTAURANT STATS ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.patch("/:id", requireAuth,  async (req: any, res) => {
  try {
    const restaurantId = req.params.id;
    const {
      restaurantName,
      restaurantType,
      restaurantAddress,
      restaurantLogo,
      restaurantBanner,
      establishmentYear,
      seatingCapacity,
      city,
      state,
      postalCode,
      description,
      phoneNumber,
      email,
      website,
      cuisine,
      defaultGstPercentage
    } = req.body;
    const user = req.user;
    const updatedAt = new Date();
    
    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }
    // ✅ 2. VERIFY OWNER OR MANAGER ACCESS
    const hasAccess = await isRestaurantOwnerOrManager(
      user.id,
      restaurantId
    );
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. PERFORM UPDATE
    const [updatedRestaurant] = await db
      .update(restaurants)
      .set({
        ...(restaurantName !== undefined && { restaurantName }),
        ...(restaurantType !== undefined && { restaurantType }),
        ...(restaurantAddress !== undefined && { restaurantAddress }),
        ...(restaurantLogo !== undefined && { restaurantLogo }),
        ...(restaurantBanner !== undefined && { restaurantBanner }),
        ...(establishmentYear !== undefined && { establishmentYear }),
        ...(seatingCapacity !== undefined && { seatingCapacity }),
        ...(city !== undefined && { city }),
        ...(state !== undefined && { state }),
        ...(postalCode !== undefined && { postalCode }),
        ...(description !== undefined && { description }),
        ...(phoneNumber !== undefined && { phoneNumber }),
        ...(email !== undefined && { email }),
        ...(website !== undefined && { website }),
        ...(cuisine !== undefined && { cuisine }),
        ...(defaultGstPercentage !== undefined && { defaultGstPercentage }),
        updatedAt,
      })
      .where(eq(restaurants.id, restaurantId))
      .returning();

    if (!updatedRestaurant) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    // ✅ 4. SUCCESS RESPONSE
    res.status(200).json({ restaurant: updatedRestaurant });
  } catch (error) {
    console.error("UPDATE RESTAURANT ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.patch("/:id/close", requireAuth, async (req: any, res) => {
  try {
    const restaurantId = req.params.id;
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }
    // ✅ 2. VERIFY OWNER OR MANAGER ACCESS
    const hasAccess = await isRestaurantOwnerOrManager(
      user.id,
      restaurantId
    );
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. PERFORM UPDATE
    const [updatedRestaurant] = await db
      .update(restaurants)
      .set({
        isOpen: false,
        updatedAt: new Date(),
      })
      .where(eq(restaurants.id, restaurantId))
      .returning();

    if (!updatedRestaurant) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    // ✅ 4. SUCCESS RESPONSE
    res.status(200).json({ restaurant: updatedRestaurant });
  } catch (error) {
    console.error("CLOSE RESTAURANT ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.patch("/:id/open", requireAuth, async (req: any, res) => {
  try {
    const restaurantId = req.params.id;
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }
    // ✅ 2. VERIFY OWNER OR MANAGER ACCESS
    const hasAccess = await isRestaurantOwnerOrManager(
      user.id,
      restaurantId
    );
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. PERFORM UPDATE
    const [updatedRestaurant] = await db
      .update(restaurants)
      .set({
        isOpen: true,
        updatedAt: new Date(),
      })
      .where(eq(restaurants.id, restaurantId))
      .returning();

    if (!updatedRestaurant) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    // ✅ 4. SUCCESS RESPONSE
    res.status(200).json({ restaurant: updatedRestaurant });
  } catch (error) {
    console.error("OPEN RESTAURANT ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/:id/status", async (req, res) => {
  try {
    const restaurantId = req.params.id;
    const restaurant = await db
      .select()
      .from(restaurants)
      .where(eq(restaurants.id, restaurantId))
      .limit(1);

    if (restaurant.length === 0) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    res.status(200).json({ isOpen: restaurant[0].isOpen });
  } catch (error) {
    console.error("FETCH RESTAURANT STATUS ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get user's restaurant role
router.get("/:id/my-role", requireAuth, async (req: any, res) => {
  try {
    const restaurantId = req.params.id;
    const user = req.user;
    console.log("MY ROLE REQUEST - User:", user);
    console.log("MY ROLE REQUEST - Restaurant ID:", restaurantId);

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      console.log("MY ROLE - Auth failed, user role:", user?.role);
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. GET ROLE
    console.log("MY ROLE - Calling getRestaurantRole for user:", user.id, "restaurant:", restaurantId);
    const role = await getRestaurantRole(user.id, restaurantId);
    console.log("MY ROLE - Role result:", role);
    
    if (!role) {
      console.log("MY ROLE - No role found for user:", user.id, "in restaurant:", restaurantId);
      return res.status(403).json({ message: "You are not a member of this restaurant" });
    }

    // ✅ 3. SUCCESS RESPONSE
    console.log("MY ROLE - Returning role:", role);
    res.status(200).json({ role });
  } catch (error) {
    console.error("FETCH RESTAURANT ROLE ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get restaurant dashboard stats
router.get("/:id/dashboard/stats", requireAuth, async (req: any, res) => {
  try {
    const restaurantId = req.params.id;
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. PERMISSION CHECK
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. GET TODAY'S STATS
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Today's orders count and revenue
    const todayOrders = await db
      .select({
        count: sql<number>`count(*)`,
        revenue: sql<number>`sum(${tableSession.finalBillAmount})`,
      })
      .from(tableSession)
      .where(
        and(
          eq(tableSession.restaurantId, restaurantId),
          gte(tableSession.billedAt, today),
          sql`${tableSession.billedAt} < ${tomorrow}`
        )
      );

    // Today's reservations count
    const todayReservations = await db
      .select({
        count: sql<number>`count(*)`,
      })
      .from(reservations)
      .where(
        and(
          eq(reservations.restaurantId, restaurantId),
          gte(reservations.reservationTime, today),
          sql`${reservations.reservationTime} < ${tomorrow}`
        )
      );

    // Total tables and occupied tables
    const totalTables = await db
      .select({
        count: sql<number>`count(*)`,
      })
      .from(tables)
      .where(eq(tables.restaurantId, restaurantId));

    const occupiedTables = await db
      .select({
        count: sql<number>`count(*)`,
      })
      .from(tables)
      .where(
        and(
          eq(tables.restaurantId, restaurantId),
          eq(tables.liveStatus, "occupied")
        )
      );

    // ✅ 4. SUCCESS RESPONSE
    res.status(200).json({
      stats: {
        todayOrders: todayOrders[0]?.count || 0,
        todayRevenue: todayOrders[0]?.revenue || 0,
        todayReservations: todayReservations[0]?.count || 0,
        totalTables: totalTables[0]?.count || 0,
        occupiedTables: occupiedTables[0]?.count || 0,
        availableTables: (totalTables[0]?.count || 0) - (occupiedTables[0]?.count || 0),
      },
    });
  } catch (error) {
    console.error("FETCH DASHBOARD STATS ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;