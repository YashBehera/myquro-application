import { Router } from "express";
import { db } from "../db/db";
import { reservations } from "../db/schema/reservations";
import { tables } from "../db/schema/tables";
import { and, eq } from "drizzle-orm";
import { requireAuth } from "../auth/requireAuth";
import { isRestaurantOwnerOrManager } from "../lib/checkRoles";
import { sendNotification } from "../lib/sendNotification";

const router = Router();

// POST /api/reservations/:reservationId/create
router.post("/:reservationId/create", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { reservationId } = req.params;
    const { tableId } = req.body;

    // 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    // 2. CREATE RESERVATION
    await db
      .insert(reservations)
      .values({
        id: reservationId,
        restaurantId: req.body.restaurantId,
        numberOfGuests: req.body.numberOfGuests,
        reservationTime: new Date(req.body.reservationTime),
        reservedBy: user.id,
        specialRequests: req.body.specialRequests || null,
      })
      .returning();
    // 3. SEND NOTIFICATION TO RESTAURANT
    await sendNotification(
      req.body.restaurantId,
      `New reservation created by ${user.name} for ${req.body.numberOfGuests} guests.`,
      "order-update"
    );
  } catch (error) {
    console.error("Error creating reservation:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// POST /api/reservations/:reservationId/assign-table
router.post(
  "/:reservationId/assign-table",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { reservationId } = req.params;
      const { tableId } = req.body;

      // 1. AUTH CHECK
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      if (!(await isRestaurantOwnerOrManager(user.id, req.body.restaurantId))) {
        return res
          .status(403)
          .json({ message: "You do not have permission to assign tables" });
      }
      
      // 2. ASSIGN TABLE TO RESERVATION
        await db
        .update(tables)
        .set({
            isReserved: true,
            reservationId: reservationId,
            liveStatus: "reserved",
        })
        .where(eq(tables.id, tableId));
        await db
        .update(reservations)
        .set({
            status: "confirmed",
        })
        .where(eq(reservations.id, reservationId));

        // 3. SEND NOTIFICATION
        await sendNotification(
          req.body.restaurantId,
          `Reservation has been assigned to table ${tableId}.`,
          "order-update"
        );

        return res.status(200).json({
        message: "Table assigned to reservation successfully",
        });
    } catch (error) {
      console.error("Error assigning table to reservation:", error);
      return res.status(500).json({
        message: "Internal server error",
      });
    }
  }
);

// GET /api/reservations/my
router.get("/my", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;

    // 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    // 2. FETCH USER RESERVATIONS
    const userReservations = await db
      .select()
      .from(reservations)
      .where(eq(reservations.reservedBy, user.id));

    return res.status(200).json({ reservations: userReservations });
  } catch (error) {
    console.error("Error fetching user reservations:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// GET /api/reservations/:reservationId
router.get("/:reservationId", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { reservationId } = req.params;

    // 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    // 2. FETCH RESERVATION DETAILS
    const reservation = (
      await db
        .select()
        .from(reservations)
        .where(eq(reservations.id, reservationId))
        .limit(1)
    )[0];

    if (!reservation) {
      return res.status(404).json({ message: "Reservation not found" });
    }

    // 3. AUTHORIZATION CHECK
    if (reservation.reservedBy !== user.id || !(await isRestaurantOwnerOrManager(user.id, reservation.restaurantId))) {
      return res
        .status(403)
        .json({ message: "You do not have access to this reservation" });
    }

    return res.status(200).json({ reservation });
  } catch (error) {
    console.error("Error fetching reservation details:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// GET /api/:restaurantId/reservations
router.get("/:restaurantId/reservations", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { restaurantId } = req.params;

    // 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    if (!(await isRestaurantOwnerOrManager(user.id, restaurantId))) {
      return res
        .status(403)
        .json({ message: "You do not have permission to view reservations" });
    }

    // 2. FETCH RESTAURANT RESERVATIONS
    const restaurantReservations = await db
      .select()
      .from(reservations)
      .where(eq(reservations.restaurantId, restaurantId));

    return res.status(200).json({ reservations: restaurantReservations });
  } catch (error) {
    console.error("Error fetching restaurant reservations:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});


// PATCH /api/reservations/:reservationId/cancel
router.patch("/:reservationId/cancel", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { reservationId } = req.params;

    // 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    // 2. CANCEL RESERVATION
    const result = await db
      .update(reservations)
      .set({ status: "cancelled" })
      .where(
        and(
          eq(reservations.id, reservationId),
          eq(reservations.reservedBy, user.id)
        )
      )
      .returning();

      await sendNotification(
        req.body.restaurantId,
        `Reservation ${reservationId} has been cancelled by the user.`,
        "order-update"
      );

    if (result.length === 0) {
      return res
        .status(404)
        .json({ message: "Reservation not found or not owned by user" });
    }

    await db
      .update(tables)
      .set({
          isReserved: false,
          reservationId: null,
          liveStatus: "available",
      })
      .where(eq(tables.reservationId, reservationId));

    return res.status(200).json({
      message: "Reservation cancelled successfully",
    });
  } catch (error) {
    console.error("Error cancelling reservation:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// PATCH /api/reservations/:reservationId/reject
router.patch("/:reservationId/reject", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { reservationId } = req.params;
    const { restaurantId } = req.body;

    // 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    // 2. RESERVATION CHECK
    if (!(await isRestaurantOwnerOrManager(user.id, restaurantId))) {
      return res
        .status(403)
        .json({ message: "You do not have permission to reject reservations" });
    }

    // 3. REJECT RESERVATION
    const result = await db
      .update(reservations)
      .set({ status: "rejected" })
      .where(eq(reservations.id, reservationId))
      .returning();

    await sendNotification(
      restaurantId,
      `Reservation ${reservationId} has been rejected.`,
      "order-update"
    );

    if (result.length === 0) {
      return res.status(404).json({ message: "Reservation not found" });
    }

    return res.status(200).json({
      message: "Reservation rejected successfully",
    });
  } catch (error) {
    console.error("Error rejecting reservation:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

export default router;