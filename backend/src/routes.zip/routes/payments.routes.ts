import { Router } from "express";
import { requireAuth } from "../auth/requireAuth";
import { db } from "../db/db";
import { nanoid } from "nanoid";
import { payments } from "../db/schema/payments";
import { tableSession } from "../db/schema/table-session";
import { and, eq } from "drizzle-orm";
const router = Router();

router.post("/:tableSessionId/pay", requireAuth, async (req: any, res) => {
  try {
    const { tableSessionId } = req.params;
    const { amount, method, referenceNumber } = req.body;
    const paidByUserId = req.user.id;

    if (!amount || amount <= 0) {
      return res.status(400).json({
        error: "Valid payment amount is required",
      });
    }

    if (!method) {
      return res.status(400).json({
        error: "Payment method is required",
      });
    }

    // ✅ 1. Fetch table session
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(eq(tableSession.id, tableSessionId))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ error: "Table session not found" });
    }

    // ✅ 2. Hard lifecycle blocks
    if (session.status === "cancelled") {
      return res.status(400).json({
        error: "Cannot accept payment on a cancelled session",
      });
    }

    if (session.paymentStatus === "paid") {
      return res.status(400).json({
        error: "This session is already fully paid",
      });
    }

    // ✅ 3. Bill must be frozen
    if (session.status !== "payment_pending") {
      return res.status(400).json({
        error: "Bill must be frozen before accepting payment",
      });
    }

    if (!session.finalBillAmount) {
      return res.status(400).json({
        error: "Final bill not found on session",
      });
    }

    const finalAmount = session.finalBillAmount; // ✅ PAISE

    // ✅ 4. Sum existing successful payments
    const existingPayments = await db
      .select()
      .from(payments)
      .where(
        and(
          eq(payments.tableSessionId, tableSessionId),
          eq(payments.status, "success")
        )
      );

    const totalPaid = existingPayments.reduce((sum, p) => sum + p.amount, 0);

    // ✅ 5. Overpayment protection
    if (totalPaid + amount > finalAmount) {
      return res.status(400).json({
        error: "Payment exceeds remaining bill amount",
        remaining: finalAmount - totalPaid,
      });
    }

    // ✅ 6. Insert payment
    const payment = (
      await db
        .insert(payments)
        .values({
          id: nanoid(),
          tableSessionId,
          restaurantId: session.restaurantId,
          amount, // ✅ PAISE
          method,
          status: "success",
          referenceNumber,
          paidByUserId,
          isRefund: false,
        })
        .returning()
    )[0];

    // ✅ 7. Update session payment state
    const newTotalPaid = totalPaid + amount;

    let newPaymentStatus: "unpaid" | "partial" | "paid" = "partial";
    let newSessionStatus: "payment_pending" | "closed" = session.status;

    if (newTotalPaid === finalAmount) {
      newPaymentStatus = "paid";
      newSessionStatus = "closed";
    }

    await db
      .update(tableSession)
      .set({
        paymentStatus: newPaymentStatus,
        status: newSessionStatus,
      })
      .where(eq(tableSession.id, tableSessionId));

    return res.status(200).json({
      message: "Payment recorded successfully",
      payment,
      paymentStatus: newPaymentStatus,
      sessionStatus: newSessionStatus,
      remainingAmount: finalAmount - newTotalPaid,
    });
  } catch (error) {
    console.error("Payment processing error:", error);
    return res.status(500).json({
      error: "Failed to process payment",
    });
  }
});
export default router;
