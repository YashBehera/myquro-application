import { Router } from "express";
import { requireAuth } from "../auth/requireAuth";
import { db } from "../db/db";
import { and, eq } from "drizzle-orm";
import {
  totalBillingAmount,
  finalAmount,
  calculateSubtotal,
  calculateDiscount,
  calculateTaxableBase,
  calculateGST,
  calculateGrandTotal,
} from "../lib/billing";
import { tableSession } from "../db/schema/table-session";
import { orderItems } from "../db/schema/order-items";
import { isRestaurantOwnerOrManager } from "../lib/checkRoles";

const router = Router();

// Define your billing routes here
router.get("/:tableSessionId/total", requireAuth, async (req, res) => {
  const { tableSessionId } = req.params;

  try {
    const totalAmount = await totalBillingAmount(tableSessionId);
    res.json({ totalAmount });
  } catch (error) {
    res.status(500).json({
      error:
        error instanceof Error ? error.message : "An unknown error occurred",
    });
  }
});

router.get("/:tableSessionId/final-amount", requireAuth, async (req, res) => {
  const { tableSessionId } = req.params;
  const { discountPercentage, taxRate } = req.query;

  try {
    const totalAmount = await totalBillingAmount(tableSessionId);
    const finalAmt = await finalAmount(
      tableSessionId,
      totalAmount,
      Number(discountPercentage) || 0,
      Number(taxRate) || 0
    );
    res.json({ finalAmount: finalAmt });
  } catch (error) {
    res.status(500).json({
      error:
        error instanceof Error ? error.message : "An unknown error occurred",
    });
  }
});

router.post("/:tableSessionId/generate-bill", requireAuth, async (req:any, res) => {
  const { tableSessionId } = req.params;
  const user = req.user;
  let { discountPercentage, taxRate } = req.body;
  const {restaurantId} = req.body;
  try {
    // 1️⃣ Fetch session
    const session = await db
      .select()
      .from(tableSession)
      .where(eq(tableSession.id, tableSessionId))
      .limit(1);

    if (session.length === 0) {
      return res.status(404).json({ error: "Table session not found" });
    }

    if (session[0].status === "cancelled") {
      return res.status(400).json({ error: "Cannot bill a cancelled session" });
    }

    if (session[0].paymentStatus === "paid") {
      return res.status(400).json({ error: "Session already paid" });
    }

    if (!(await isRestaurantOwnerOrManager(user.id, restaurantId))){
      discountPercentage = 0;
    }

    // 2️⃣ Fetch served items
    const sessionOrders = await db
      .select({
        quantity: orderItems.quantity,
        unitPrice: orderItems.unitPrice,
      })
      .from(orderItems)
      .where(
        and(
          eq(orderItems.tableSessionId, tableSessionId),
          eq(orderItems.status, "served")
        )
      );

    // 3️⃣ Recalculate everything fresh
    const subtotal = calculateSubtotal(sessionOrders);

    const discountAmount = calculateDiscount(
      subtotal,
      Number(discountPercentage)
    );

    const taxableAmount = calculateTaxableBase(subtotal, discountAmount);

    const gstAmount = calculateGST(taxableAmount, Number(taxRate));

    const grandTotal = calculateGrandTotal(taxableAmount, gstAmount);

    // 4️⃣ Freeze values & mark as paid
    await db
      .update(tableSession)
      .set({
        frozenSubtotal: subtotal,
        frozenDiscountAmount: discountAmount,
        frozenTaxableAmount: taxableAmount,
        frozenGstAmount: gstAmount,
        grandTotal,
        paymentStatus: "payment_pending",
        status: "payment_pending",
        finalBillAmount: grandTotal,
      })
      .where(eq(tableSession.id, tableSessionId));

    // 5️⃣ Response
    return res.status(200).json({
      message: "Bill generated successfully",
      tableSessionId,
      subtotal,
      discountAmount,
      taxableAmount,
      gstAmount,
      grandTotal,
    });
  } catch (error) {
    return res.status(500).json({
      error:
        error instanceof Error ? error.message : "An unknown error occurred",
    });
  }
});

// GET /:tableSessionId/e-bill - Generate e-bill for table session
router.get("/:tableSessionId/e-bill", requireAuth, async (req: any, res) => {
  try {
    const { tableSessionId } = req.params;
    const user = req.user;

    // ✅ 1. GET TABLE SESSION
    const session = await db
      .select()
      .from(tableSession)
      .where(eq(tableSession.id, tableSessionId))
      .limit(1);

    if (session.length === 0) {
      return res.status(404).json({ message: "Table session not found" });
    }

    // ✅ 2. PERMISSION CHECK (restaurant staff or customer who owns the session)
    let hasAccess = false;
    if (user.role === "restaurant") {
      hasAccess = await isRestaurantOwnerOrManager(user.id, session[0].restaurantId);
    } else if (user.role === "customer" && session[0].customerId) {
      hasAccess = session[0].customerId === user.id;
    }

    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. GET ORDER ITEMS FOR THE SESSION
    const sessionOrders = await db
      .select({
        orderId: orderItems.orderId,
        menuItemId: orderItems.menuItemId,
        variantId: orderItems.variantId,
        quantity: orderItems.quantity,
        price: orderItems.price,
        total: orderItems.total,
        notes: orderItems.notes,
      })
      .from(orderItems)
      .innerJoin(tableSession, eq(orderItems.orderId, tableSession.id))
      .where(eq(tableSession.id, tableSessionId));

    // ✅ 4. CALCULATE BILL DETAILS
    const subtotal = session[0].frozenSubtotal || calculateSubtotal(sessionOrders);
    const discountAmount = session[0].frozenDiscountAmount || 0;
    const taxableAmount = session[0].frozenTaxableAmount || calculateTaxableBase(subtotal, discountAmount);
    const gstAmount = session[0].frozenGstAmount || calculateGST(taxableAmount);
    const grandTotal = session[0].grandTotal || calculateGrandTotal(taxableAmount, gstAmount);

    // ✅ 5. GENERATE E-BILL DATA
    const eBill = {
      tableSessionId,
      restaurantId: session[0].restaurantId,
      customerId: session[0].customerId,
      startedAt: session[0].startedAt,
      billGeneratedAt: new Date(),
      items: sessionOrders,
      billSummary: {
        subtotal: subtotal.toFixed(2),
        discountAmount: discountAmount.toFixed(2),
        taxableAmount: taxableAmount.toFixed(2),
        gstAmount: gstAmount.toFixed(2),
        grandTotal: grandTotal.toFixed(2),
      },
      paymentStatus: session[0].paymentStatus,
      notes: session[0].notes,
    };

    // ✅ 6. SUCCESS RESPONSE
    res.status(200).json({
      eBill,
      message: "E-bill generated successfully"
    });
  } catch (error) {
    console.error("E-BILL GENERATION ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
